import java.awt.Button;
import java.awt.Frame;
import java.awt.event.*;

import javax.swing.JButton;




//NEW GAME BUTTON IS OK AS IS BUT COULD CHANGE

//CREATES ANONYMOUS CLASSES!!
public class NewGame extends JButton implements ActionListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private Button bttn;
	
	
	public NewGame()
	{
		bttn = new Button();
		bttn.addActionListener(this);
		bttn.setEnabled(true);
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e)
	{
		
		/**
			Prevents multiple windows from being open
			this way when you select new game you always have only 
			one instance of the MiniGame Object running
			 
		 **/
		
		MiniGame game = new MiniGame();
		
		Frame [] numframe = game.getFrames();
		
		if(numframe.length > 1)
		{
			for(int i = 1; i<numframe.length-1; i++)
			{
				numframe[i].dispose();
			}
		}
	}
};