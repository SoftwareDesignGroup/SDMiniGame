import java.awt.Button;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JOptionPane;


public class Reset extends JButton implements ActionListener{
	private Button bttn;
	public Reset()
	{
		bttn = new Button();
		bttn.addActionListener(this);
		bttn.setEnabled(true);
	}
	
	public void actionPerformed(ActionEvent e)
	{}
}
	
