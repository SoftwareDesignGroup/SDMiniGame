import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.awt.image.CropImageFilter;
import java.awt.image.FilteredImageSource;
import java.io.IOException;

import javax.swing.ImageIcon;

public class Maze extends Component
{
	private ImageIcon img;
	private Image image;
	
	private Image[] images;  //original
	private Image[] master; // copy of Original
	private Image[] unshuffled; // for solution
	
	
	private String name = "landscape6";
	private BufferedImage bImage;
	//************************************************
	
	public Maze()
	{
		editImage(name);
	}
	//++++++++++++++++++++++++++++++++++++++++++
	
	
	
	public void editImage(String imagename)
	{
		
		
		//try getting img
		
		try
		{
			bImage = loadImage(imagename);
		}
		catch(IOException e)
		{
			System.out.println(e.getMessage());
		}
		//---------------------------------------------
		
		
		bImage = resizeImage(bImage); //resize img for 16x16 crop
		
		
		images = new Image[16];
		master = new Image[16];
		unshuffled = new Image[16];
		
		
		//Crop image and send crops to arrays
		int index = 0;
		for (int i = 0; i < 4; i++) 
		{
            for (int j = 0; j < 4; j++) 
            {
                image = createImage(new FilteredImageSource(bImage.getSource(),
                        new CropImageFilter(j * bImage.getWidth() / 4, i * bImage.getHeight() / 4,
                                (bImage.getWidth() / 4), bImage.getHeight() / 4)));
                images[index] = image;
                unshuffled[index] = image;
                master[index] = image;
                index++;
            }
		}
	}
	//++++++++++++++++++++++++++++++++++++++++++
	
	
	
	//Resize Image to fit GameBoard
	private BufferedImage resizeImage(BufferedImage original) 
	{
        BufferedImage resized = new BufferedImage(320, 320, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = resized.createGraphics();
        g.drawImage(original, 0, 0, 320, 320, null);
        g.dispose();
        return resized;
	}
	//++++++++++++++++++++++++++++++++++++++++++
	
	
	
	/**
	 * 
	In Order to get Image from Image Package
	You need to Convert from Image to BufferdImage
	This Method does So.
	 
	Adding in the Previous Version that simply opens a 
	file and reads an image in,
	Is easy enough and could be done if need be.
	
	Advantage of a package is that everything is in one place
	And it simplifies the Path of the image
	
	**/
	
	private BufferedImage loadImage(String name) throws IOException 
	{
		Image img = Toolkit.getDefaultToolkit().getImage(
					MiniGame.class.getResource("/images/"+name+".jpg"));
		img = new ImageIcon(img).getImage();

		    BufferedImage bimage = new BufferedImage(img.getWidth(null), img.getHeight(null),
		        BufferedImage.TYPE_INT_ARGB_PRE);

		    Graphics g = bimage.createGraphics();
		    g.drawImage(img, 0, 0, null);
		    g.dispose();
		    return bimage;
    }
	//++++++++++++++++++++++++++++++++++++++++++
	
	
	
	
	//A bunch of gets for all the arrays
	
	
	public ImageIcon getUnshuffled(int i)
	{
		img = new ImageIcon(unshuffled[i]);
		return img;
	}
	//++++++++++++++++++++++++++++++++++++++++++
	
	
	
	
	
	public ImageIcon getImages(int i)
	{
		img = new ImageIcon(images[i]);
		return img;
	}
	//++++++++++++++++++++++++++++++++++++++++++
	
	
	
	
	
	public ImageIcon getMaster(int i)
	{
		img = new ImageIcon(master[i]);
		return img;
	}
	//++++++++++++++++++++++++++++++++++++++++++
	
		
}
