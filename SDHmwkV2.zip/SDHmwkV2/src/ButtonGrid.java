import java.awt.GridLayout;

import javax.swing.JPanel;




//THIS IS A SKELETON FOR BUTTON GRID
class ButtonGrid extends JPanel{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private JPanel grid;
	
	public GridLayout layout = new GridLayout(3,1);
	
	public ButtonGrid() {grid = new JPanel(layout);}
}