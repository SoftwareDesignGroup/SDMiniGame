import java.awt.*;
import javax.swing.*;



class SolGrid{
	
	private JPanel grid;
	private Maze img = new Maze();
	private Tile[] solve;
	//------------------------
	
	public SolGrid() {fillBoard();}
	

	public void fillBoard() 
    {
		solve = new Tile[16];  //tiles used for Solution
		//---------------------------
	
		setSolve();	//Fill solve array
		
    }
	
	

	public void setSolve()         //set solve array
	{
		//SetUp for Solution:
    	
    	for(int i = 0; i<solve.length; i++)
    	{
    		solve[i] = new Tile();
    		solve[i].setPreferredSize(new Dimension(80,80));
    		solve[i].setIcon(img.getUnshuffled(i));
    		solve[i].setIdentifier("Tile_" + (i + 1)); 
    		//---------------------------------------------
    	}
    
   }
	
	
   public Tile[] getSolve() {return solve;}  //get solve array
	
	
}
