

import javax.swing.JButton;

public class Solve extends JButton{
	private JButton bttn;
	private SolGrid winningTiles;
	public Solve()
	{
		bttn = new JButton();
		bttn.setEnabled(true);
		winningTiles = new SolGrid(); //solution
	}
	
	public SolGrid getWinningTiles()  {return winningTiles;}  //get solution
}
