
import javax.swing.JButton;

public class Check extends JButton
{
	private JButton check;
	private SolGrid correct;
	
	public Check()
	{
		check = new JButton();
		correct = new SolGrid(); //solution
	}
	public SolGrid getCorrect()  {return correct;}  //get solution
}
