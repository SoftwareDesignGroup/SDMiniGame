import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Arrays;
import java.util.Collections;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

public class MiniGame extends Frame implements ActionListener
{
	private GameBoard gb;
	private ButtonGrid bgrid;
	private TileGrid tgridL;
	private TileGrid tgridR;
	private TileGrid master;
	private NewGame newgame;
	private Quit quit;
	private Reset reset;
	private Check check;
	private Solve solve;
	private ImgSelect selector;
	private JFrame window;
	private Tile tilesToSwap[];
	private Color vanilla;
	private Color claret;
	private Dimension buttonsize;
	private Dimension buttongridDim;  //Button Grid Size
	private Dimension tilegridDim;    //Tile Grid Size
	private Dimension gameboardDim;   // Game Board Size
	private int windowL;  //window length
	private int windowH;  //window height
	private int r; //counter for reset
	
	public MiniGame()
	{
		
		vanilla = new Color(243,229,171);
		claret = new Color(127,23,52);
		tilesToSwap = new Tile[2];
		buttonsize = new Dimension(125,50);
		buttongridDim = new Dimension(0,65);
		tilegridDim = new Dimension(175,0);
		gameboardDim = new Dimension(317,317);
		r = 2;
		windowL = 1000;
		windowH = 650;
				
		
		
		//New Game Button SetUp
		
		newgame = new NewGame();
		newgame.setPreferredSize(buttonsize);
		newgame.setText("New Game");
		newgame.addActionListener(newgame);
		newgame.setBorder(BorderFactory.createLineBorder(vanilla,2,true));
		newgame.setForeground(vanilla);
		//-----------------------------------------------------		
		
		
		//Quit Button SetUp
		
		quit = new Quit();
		quit.setPreferredSize(buttonsize);
		quit.setText("Quit");
		quit.addActionListener(quit);
		quit.setBorder(BorderFactory.createLineBorder(vanilla,2,true));
		quit.setForeground(vanilla);
		//-----------------------------------------------------		
		
		
		//Reset Button SetUp
		
		reset = new Reset();
		reset.setPreferredSize(buttonsize);
		reset.setText("Reset");		
		reset.addActionListener(this);
		reset.setBorder(BorderFactory.createLineBorder(vanilla,2,true));
		reset.setForeground(vanilla);
		//-----------------------------------------------------	
		
		
		//Solve Button SetUp
		
		solve = new Solve();
		solve.setPreferredSize(buttonsize);
		solve.setText("Solve");
		solve.addActionListener(this);
		solve.setBorder(BorderFactory.createLineBorder(vanilla,2,true));
		solve.setForeground(vanilla);
		//-----------------------------------------------------
		
		
		//Check Button SetUp
		
		check = new Check();
		check.setPreferredSize(buttonsize);
		check.setText("Check-UC");
		check.addActionListener(this);
		check.setBorder(BorderFactory.createLineBorder(vanilla,2,true));
		check.setForeground(vanilla);
		//-----------------------------------------------------
		
		
		//ImgSelect Button SetUp
		
		selector = new ImgSelect();
		selector.setPreferredSize(buttonsize);
		selector.setText("New Image - UC");
		selector.addActionListener(selector);
		selector.setBorder(BorderFactory.createLineBorder(vanilla,2,true));
		selector.setForeground(vanilla);
		


		//Button Grid SetUp
		
		bgrid = new ButtonGrid();
		bgrid.setPreferredSize(buttongridDim);
		bgrid.add(newgame).setLocation(1, 1);
		bgrid.add(quit).setLocation(1, 2);
		bgrid.add(reset).setLocation(1,3);
		bgrid.add(solve).setLocation(1, 5);
		bgrid.add(check).setLocation(1,4);
		bgrid.add(selector).setLocation(1,6);
		bgrid.setOpaque(false);
		
		insertGameTiles();
		
		//-----------------------------------------------------
		
		
		JPanel contentPane;
		contentPane = new JPanel(new GridBagLayout())  //Set Background Image
				{
					public void paintComponent(Graphics g)
					{
						Image img = Toolkit.getDefaultToolkit().getImage(
								MiniGame.class.getResource("/backgrounds/bg4.jpg"));
						g.drawImage(img, 0, 0, this.getWidth(), this.getHeight(),this);
								
					}
				};
		
		
		//Main Window Set Up
		
		window = new JFrame();
		window.setSize(windowL,windowH);
		window.add(contentPane);
		
		windowSetUp(contentPane);
		
		window.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		window.setVisible(true);
		
	}
	
	//-----------------------------------------------------------------------------
	
	
	
	
	public void swapTiles(Tile t1, Tile t2)
	{
		if(t1 != t2)
		{
			String x;
			x = t1.getIdentifier();
			t1.setIdentifier(t2.getIdentifier());
			t2.setIdentifier(x);
		
		
		String z;
		z = t1.getIdentifier();
		t1.setIdentifier(t2.getIdentifier());
		t2.setIdentifier(z);
		
		
			ImageIcon y = new ImageIcon();
			y = (ImageIcon) t1.getIcon();
			t1.setIcon(t2.getIcon());
			t2.setIcon(y);
			t1.setBorder(BorderFactory.createLineBorder(vanilla,2,true));
			for(int i = 0; i<gb.getTiles().length; i++)
			{
				gb.getTiles()[i].setBorder(BorderFactory.createEmptyBorder());
			}
		}
		
		else
		{
			t1.setBorder(BorderFactory.createLineBorder(vanilla,2,true));
			for(int i = 0; i<gb.getTiles().length; i++)
			{
				gb.getTiles()[i].setBorder(BorderFactory.createEmptyBorder());
			}
		}
		
	}
	
	//------------------------------------------------------------------------------
	
	
	
	
	public  void actionPerformed(ActionEvent e)
	{
		if(e.getActionCommand() == "Reset")
		{
			master.reset();
			if(r%2 != 0 || r==0)
			{
				for(int i=0; i<tgridL.getLeft().length; i++)
				{
					tgridL.getLeft()[i].setIcon(master.getLeft()[i].getIcon());
					tgridR.getRight()[i].setIcon(master.getRight()[i].getIcon());
				}
				
			}
			else if(r%2 == 0)
			{
				
				for(int i=0; i<tgridL.getLeft().length; i++)
				{
					tgridL.getLeft()[i].setIcon(master.getRight()[i].getIcon());
					tgridR.getRight()[i].setIcon(master.getLeft()[i].getIcon());
				}
				

			}
				
			
			for(int i=0; i<gb.getTiles().length; i++) //set board icons to null for reset
			{
				gb.getTiles()[i].setIcon(null);
				gb.getTiles()[i].setIdentifier(null);
			}
			
			JOptionPane reset = new JOptionPane();
			JOptionPane.showMessageDialog(null, "Game has been reset!");
			r++;
			return;
		}
		
		
		//----------------------------------------------------------------------------------------------
		
		
		
		
		else if(e.getActionCommand() == "Solve")
		{
			for(int i = 0; i < tgridL.getLeft().length; i++)
			{
				tgridL.getLeft()[i].setIcon(null);
				tgridR.getRight()[i].setIcon(null);
				tgridL.getLeft()[i].setBorder(BorderFactory.createLineBorder(vanilla,2,true));
				tgridR.getRight()[i].setBorder(BorderFactory.createLineBorder(vanilla,2,true));
		
			}
			
			for(int i=0; i<gb.getTiles().length; i++) //get/set winning position
			{
				gb.getTiles()[i].setIcon(solve.getWinningTiles().getSolve()[i].getIcon());
				gb.getTiles()[i].setIdentifier(solve.getWinningTiles().getSolve()[i].getIdentifier());
			}
			gameWon();
			return;
		}
		
		//----------------------------------------------------------------------------------------------
		
		else if(e.getActionCommand() == "Check-UC")  //Under Construction
		{
			gb.print();
			if(gb.gameWon())
			{
				JOptionPane won = new JOptionPane();
				won.showMessageDialog(null, "You Win!");
			}
			else
			{
				JOptionPane wrong = new JOptionPane();
				wrong.showMessageDialog(null, "Wrong!");
			}
			return;
			
		}
		
		else if(e.getActionCommand() == "New Image-UC")  //Under Construction
		{
	
			JOptionPane info = new JOptionPane();
			info.showMessageDialog(null, "New Image Pressed");
			return;
		}
		
		else
		{
			if(tilesToSwap[0] == null)
			{
				Border border = new LineBorder(Color.blue, 3);
				tilesToSwap[0] = (Tile) e.getSource();
				tilesToSwap[0].setBorder(border);
			}
			
			
			else
			{
				tilesToSwap[1] = (Tile) e.getSource();
				swapTiles(tilesToSwap[0], tilesToSwap[1]);
				tilesToSwap[0] = null;
				tilesToSwap[1] = null;
				gameWon();
			}			
		}
	}
	
	//---------------------------------------------------------------------
	
	
	//check if game has been won
	public void gameWon()
	{
		if(gb.gameWon())
		{
			JOptionPane won = new JOptionPane();
			won.showMessageDialog(null, "You Win!");
		}
	}
	
	//---------------------------------------------------------------------
	
	
	
	
	
	public void insertGameTiles()
	{
		tgridL = new TileGrid();
		tgridL.setPreferredSize(tilegridDim);
		tgridL.setOpaque(false);
		//------------------------------------------------------
		
		
		tgridR = new TileGrid();
		tgridR.setPreferredSize(tilegridDim);
		tgridR.setOpaque(false);
	  //------------------------------------------------------
		
		master = new TileGrid();
	   
	    
		gb = new GameBoard();
		gb.setPreferredSize(gameboardDim);
		gb.setLayout(new GridBagLayout());
		gb.setBorder(BorderFactory.createLineBorder(new Color(243,229,171), 2));
		gb.setOpaque(false);
		//------------------------------------------------------
		
		
	
		//Tgrid0_7 setUp
		
		for(int i = 0; i < 8; i++) //add tiles to grid
		{
			tgridL.getLeft()[i] = master.getLeft()[i];
			tgridL.getLeft()[i].addActionListener(this);
			tgridL.add(tgridL.getLeft()[i]);
		}
		
		
		
		//Tgrid8_16 set Up
		
		for(int i = 0; i < 8; i++)  //add tiles to grid
		{
			tgridR.getRight()[i] = master.getRight()[i];
			tgridR.getRight()[i].addActionListener(this);
			tgridR.add(tgridR.getRight()[i]);
		}
		
		//------------------------------------------------------
		
		
		//Game Board SetUp
		
		GameBoardSetUp();
		
		//------------------------------------------------------
		
		
		//Set Border For Tiles
		 
		for(int i = 0; i< tgridL.getLeft().length; i++)
		{
			tgridL.getLeft()[i].setBorder(BorderFactory.createLineBorder(vanilla,2,true));
			tgridR.getRight()[i].setBorder(BorderFactory.createLineBorder(vanilla,2,true));
		}
		
	}
	
	//----------------------------------------------------------------------------------------------
	
	public void windowSetUp(JComponent component)
	{
		GridBagConstraints c = new GridBagConstraints();
		
		c.anchor = GridBagConstraints.CENTER;
		c.weightx = 0.0;
		c.weighty = 0.0;
		c.insets = new Insets(0,275,0,0);
		c.gridx = 2;
		c.gridy = 2;
		c.gridwidth = 1;
		c.gridheight = 1;
		component.add(gb,c);
		
		c.anchor = GridBagConstraints.LAST_LINE_START;
		c.fill = GridBagConstraints.HORIZONTAL;
		c.weightx = 0.0001;
		c.weighty = 0.0001;
		c.ipady = 0;
		c.ipadx = 0;
		c.insets = new Insets(0,0,0,0);
		c.gridx = 1;
		c.gridy = 2;
		c.gridwidth = 3;
		component.add(bgrid,c);
		
		c.anchor = GridBagConstraints.LINE_START;
		c.fill = GridBagConstraints.VERTICAL;
		c.gridx = 0;
		c.insets = new Insets(115,10,0,0);
		c.weightx = 0.0001;
		c.weighty = 0.0001;
		component.add(tgridL,c);
		
		c.anchor = GridBagConstraints.LINE_END;
		c.fill = GridBagConstraints.VERTICAL;
		c.gridx = 3;
		c.insets = new Insets(115,0,0,10);
		c.weightx = 0.0001;
		c.weighty = 0.0001;
		component.add(tgridR, c);
		
	}
	
	private void GameBoardSetUp()
	{
		GridBagConstraints c = new GridBagConstraints();
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		c.insets = new Insets(0,0,0,0);
		//c.fill = GridBagConstraints.BOTH;
		c.ipady = 0;
		c.ipadx = 0;
		c.weightx = 0.0001;
		c.weighty = 0.0001;
		c.gridx = 0;
		c.gridy = 0;
		//c.gridwidth = 1;
		//c.gridheight = 1;
		for(int i = 0; i < gb.getTiles().length; i++)  //add tiles to board
		{
			gb.getTiles()[i].addActionListener(this);
			gb.getTiles()[i].setBorder(BorderFactory.createEmptyBorder());
		}
		gb.add(gb.getTiles()[0],c);
		c.insets = new Insets(0,78,0,0);
		gb.add(gb.getTiles()[1],c);
		c.insets = new Insets(0,155,0,0);
		gb.add(gb.getTiles()[2],c);
		c.insets = new Insets(0,233,0,0);
		gb.add(gb.getTiles()[3],c);
		c.insets = new Insets(78,0,0,0);
		gb.add(gb.getTiles()[4],c);
		c.insets = new Insets(78,78,0,0);
		gb.add(gb.getTiles()[5],c);
		c.insets = new Insets(78,155,0,0);
		gb.add(gb.getTiles()[6],c);
		c.insets = new Insets(78,233,0,0);
		gb.add(gb.getTiles()[7],c);
		c.insets = new Insets(155,0,0,0);
		gb.add(gb.getTiles()[8],c);
		c.insets = new Insets(155,78,0,0);
		gb.add(gb.getTiles()[9],c);
		c.insets = new Insets(155,155,0,0);
		gb.add(gb.getTiles()[10],c);
		c.insets = new Insets(155,233,0,0);
		gb.add(gb.getTiles()[11],c);
		c.insets = new Insets(233,0,0,0);
		gb.add(gb.getTiles()[12],c);
		c.insets = new Insets(233,78,0,0);
		gb.add(gb.getTiles()[13],c);
		c.insets = new Insets(233,155,0,0);
		gb.add(gb.getTiles()[14],c);
		c.insets = new Insets(233,233,0,0);
		gb.add(gb.getTiles()[15],c);
	}
	
}
