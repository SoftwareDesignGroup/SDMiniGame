import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Image;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JPanel;

public class TileGrid extends JPanel
{
	private GridLayout layout = new GridLayout(8,1);
	private JPanel grid;
	private Maze img = new Maze();
	private Tile[] left;
	private Tile[] right;
	private Tile[] tiles;
	private Color vanilla ;
	private Dimension size;
	
	public TileGrid()
	{
		grid = new JPanel(layout);
		fill();
	}
	
	public void fill()
	{
		left = new Tile[8];
		right = new Tile[8];
		tiles = new Tile[16];
		vanilla = new Color(243,229,171);
		size = new Dimension(80,80);
		
		
		//Fill array
		for(int i = 0; i<tiles.length; i++)
		{
			tiles[i] = new Tile();
    		tiles[i].setPreferredSize(size);
    		tiles[i].setForeground(new Color(243,229,171));
    		
    		
    		tiles[i].setIcon(img.getImages(i));
    		tiles[i].setIdentifier("Tile_" + (i + 1));
		}
		
		
		//Shuffle Array and Split it into 2
		List<Tile> temp; 
		temp = Arrays.asList(tiles);
		Collections.shuffle(temp);
		tiles = (Tile[])temp.toArray();
		
		System.arraycopy(tiles, 0, left, 0, left.length);
		System.arraycopy(tiles, right.length, right, 0, right.length);
		
		for(int  i = 0; i<left.length; i++)
		{
			left[i].setText("#"+(i+1));
    		left[i].setHorizontalTextPosition(JButton.CENTER);
    		left[i].setVerticalTextPosition(JButton.CENTER);
    		right[i].setText("#"+(i+8));
    		right[i].setHorizontalTextPosition(JButton.CENTER);
    		right[i].setVerticalTextPosition(JButton.CENTER);
		}
		
		
	}
	

	
	public void reset() { fill(); } //For Clarification Purposes I know its redundant
	public Tile[] getLeft() { return left; }
	public Tile[] getRight() { return right; }
	
	
}
