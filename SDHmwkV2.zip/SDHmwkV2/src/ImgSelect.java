import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

public class ImgSelect extends JButton implements ActionListener
{
	private JButton select;
	
	public ImgSelect()
	{
		select = new JButton();
		//select.setEnabled(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}


		
}
