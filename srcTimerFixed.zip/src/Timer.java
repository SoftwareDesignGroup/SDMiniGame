import java.util.Calendar;


//Everything in here is pretty Straight Forward

@SuppressWarnings("null")
public class Timer 
{
	private Calendar timer;
	private int hourstart;
	private int hourend;
	private int minutestart;
	private int minutend;
	private int secondstart;
	private int secondend;
	
	
	@SuppressWarnings("unqualified-field-access")
	public Timer()
	{
		//Get Initial time
		timer = Calendar.getInstance();
		hourstart = timer.get(Calendar.HOUR);
		minutestart = timer.get(Calendar.MINUTE);
		secondstart = timer.get(Calendar.SECOND);
	}
	
	
	@SuppressWarnings({ "unqualified-field-access", "nls" })
	public String getTime()
	{
		
		//Get time
		String time = new String();
		timer = Calendar.getInstance();
		hourend = timer.get(Calendar.HOUR);
		//minutend = timer.get(Calendar.MINUTE);
		//secondend = timer.get(Calendar.SECOND);
		
		
		//For Math
		int diffHour;
		int diffMinutes;
		int diffSec;
		
		
		//Remove Negative numbers
		if(hourend >= hourstart){ diffHour = hourend - hourstart; }
		else{ diffHour = hourstart-hourend; }
		
		if(minutend >= minutestart){ diffMinutes = minutend - minutestart;}
		else{ diffMinutes = minutestart - minutend;}
		
		if(secondend >= secondstart){ diffSec = secondend - secondstart;}
		else{ diffSec = secondstart - secondend; }
		

		
		
		if(diffHour > 0)
		{
			timer = Calendar.getInstance();
			minutend = timer.get(Calendar.MINUTE);
			secondend  = timer.get(Calendar.SECOND);
			
			if(minutend >= minutestart){ diffMinutes = minutend - minutestart;}
			else{ diffMinutes = minutestart - minutend;}
			
			if(secondend >= secondstart){ diffSec = secondend - secondstart;}
			else{ diffSec = secondstart - secondend; }
			
			if(diffHour < 10 && diffMinutes < 10 && diffSec < 10) { time = "0" +
			diffHour + ":" + "0" + diffMinutes + ":" + "0" + diffSec; }
			else
				time = diffHour + ":" + diffMinutes + ":" + diffSec;
			
			
		}
		else
		{
			timer = Calendar.getInstance();
			minutend = timer.get(Calendar.MINUTE);
			secondend  = timer.get(Calendar.SECOND);
			
			if(minutend >= minutestart){ diffMinutes = minutend - minutestart;}
			else{ diffMinutes = minutestart - minutend;}
			
			if(secondend >= secondstart){ diffSec = secondend - secondstart;}
			else{ diffSec = secondstart - secondend; }
			
			if(diffMinutes > 0)
			{
				if(diffMinutes < 10 && diffSec < 10){ time = "00:" + "0" + diffMinutes + ":" + "0" + diffSec; }
				else{ time = "00:" + diffMinutes + ":" + diffSec; }
			}
			else
			{
				timer = Calendar.getInstance();
				secondend = timer.get(Calendar.SECOND);
				if(secondend >= secondstart){ diffSec = secondend - secondstart;}
				else{ diffSec = secondstart - secondend; }
				
				if(diffSec < 10){ time = "00:00:" + "0" + diffSec; }
				else{ time = "00:00:" + diffSec; }
			}
			
		}
		
		
		return time;
		
		
	}
}
