import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

@SuppressWarnings("null")
public class Load extends JButton implements ActionListener
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static File file = null;
	File old = null;
	
	
	
	private static String lastLoad = null;
	//-----------------------------------------------------
	


	public static String getLastLoad()
	{
		return lastLoad;
	}
	//-----------------------------------------------------
	
	
	
	public void newload() throws FileNotFoundException
	{
		MiniGame.closeMenu();
		final JFileChooser fc = new JFileChooser();
		FileNameExtensionFilter filter = new FileNameExtensionFilter("SAV and MZE", "sav", "mze","All");
		fc.setFileFilter(filter);
		fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
		 int returnVal = fc.showOpenDialog(null);
		    if(returnVal == JFileChooser.APPROVE_OPTION) 
		    {
		       file = fc.getSelectedFile();
		    }
		
		    if(returnVal == JFileChooser.CANCEL_OPTION){return;}
		    
		String filename = file.getName();
		String extension = filename.substring(filename.lastIndexOf(".") + 1, filename.length());
		//System.out.println(extension);
		if(extension.equals("mze"))
		{
			byte [] bFile = new byte[(int)file.length()];
			FileInputStream finps = new FileInputStream(file);
			try
			{
				finps.read(bFile);
				finps.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			byte[] test = {bFile[0],bFile[1],bFile[2],bFile[3]};
			StringBuilder sb = new StringBuilder();
			for(byte b : test)
			{
				sb.append(String.format("%02X", b));
			}
			if(!sb.toString().equals("CAFEDEED") && !sb.toString().equals("CAFEBEEF"))
			{
				JOptionPane.showMessageDialog(null, "Invalid file type!");
				return;
			}
			//System.out.println(true);
			String location = file.getAbsolutePath();
			MiniGame.loadByteFile(location);
			MiniGame.setState(false);
			MiniGame.checkType();
		}
		else
		{
			try {
				MiniGame.getLeft().load(file, MiniGame.getRight(), MiniGame.getBoard());
				MiniGame.setState(false);
				MiniGame.checkType();
			} catch (ClassNotFoundException | IOException e) {
				JOptionPane.showMessageDialog(null, "Invalid Format!");
				return;
			}
		}
		
		
		
	}
	
	
	
	
	
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{ 
		try {
				newload();
				
			} 
			catch (FileNotFoundException e1) 
			{
				JOptionPane.showMessageDialog(null, "File Not Found!");
				return;
			} 		
	}
	//-----------------------------------------------------
	
	

	public static void lastLoad()
	{
		MiniGame.closeMenu();
		File input  = new File(file.getAbsolutePath());
		String filename = input.getName();
		String extension = filename.substring(filename.lastIndexOf(".") + 1, filename.length());
		//System.out.println(extension);
		//-----------------------------------------------------
		
		
		if(input == null){ return; }//Handle Cancel Button Press
		//System.out.println(filename);
		//-----------------------------------------------------
		
		if (extension.equals("mze"))
		{
			//System.out.println(location);
			MiniGame.loadByteFile(input.getAbsolutePath());
			MiniGame.setState(false);
			MiniGame.checkType();
		}
		else
		{
			try {
				MiniGame.getLeft().load(input, MiniGame.getRight(), MiniGame.getBoard());
				MiniGame.setState(false);
				MiniGame.checkType();
			} catch (ClassNotFoundException | IOException e) {
				JOptionPane.showMessageDialog(null, "Invalid Format!");
				return;
			}
		}
		//-----------------------------------------------------
		
	}
	
	public static String getPath(){ return file.getAbsolutePath(); }
	
	
}
