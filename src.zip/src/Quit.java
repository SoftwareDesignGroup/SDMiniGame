import java.awt.Button;
import java.awt.event.*;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JOptionPane;


@SuppressWarnings("null")
public class Quit extends JButton implements ActionListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private Button bttn;
	
	
	@SuppressWarnings("unqualified-field-access")
	public Quit()
	{
		bttn = new Button();
		bttn.addActionListener(this);
		bttn.setEnabled(true);
	}
	
	
	@SuppressWarnings("nls")
	public  void actionPerformed(ActionEvent e)
	{
		if(MiniGame.getStateChange())
		{
			int choice = JOptionPane.showOptionDialog(null, "Would You Like To Save?", null , JOptionPane.YES_NO_OPTION, 
					JOptionPane.QUESTION_MESSAGE, null,null,null);
			if(choice == 0)
			{
				Save save = new Save();
				try {
					save.save();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			else
			{
				System.exit(0);
			}
		}
		else
		{
			System.exit(0);
		}
	}
}