import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;


public class TileGrid extends JPanel
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private GridLayout layout = new GridLayout(8,1);
	private JPanel grid;
	private String name;
	private String defaultname = "default";
	private FileIn file;
	private Maze img;
	
	
	private Tile[] tiles, left, right, rightReset, leftReset, solution;
	
	
	private Color vanilla ;
	private Dimension size;
	//*****************************
	
	
	
	public TileGrid(){ grid = new JPanel(layout); }
	//++++++++++++++++++++++++++++++++ 
	
	
	
	public void fill()
	{
		instantiate();
		open();
		
		//Fill array
		for(int i = 0; i<tiles.length; i++)
		{
			tiles[i] = new Tile();
    		tiles[i].setPreferredSize(size);
    		tiles[i].setForeground(Color.BLUE);
    		
    		
    		tiles[i].setIcon(img.getImages(i));
    		tiles[i].setIdentifier("Tile_" + (i + 1));
		}
		
		//Set Up Solution array
		setSolve();
		
		
		
		//Shuffle Array and Split it into 2
		List<Tile> temp; 
		temp = Arrays.asList(tiles);
		Collections.shuffle(temp);
		tiles = (Tile[])temp.toArray();
		

		System.arraycopy(tiles, 0, left, 0, left.length);
		System.arraycopy(tiles, right.length, right, 0, right.length);
		
		
		//Set number of buttons without them being all shuffled
		for(int  i = 0; i<left.length; i++)
		{
			left[i].setText("#"+(i+1));
    		left[i].setHorizontalTextPosition(JButton.CENTER);
    		left[i].setVerticalTextPosition(JButton.CENTER);
    		right[i].setText("#"+(i+9));
    		right[i].setHorizontalTextPosition(JButton.CENTER);
    		right[i].setVerticalTextPosition(JButton.CENTER);
    		
    		//set up for masters
    		leftReset[i] = new Tile();
    		leftReset[i].setPreferredSize(size);
    		leftReset[i].setForeground(new Color(243,229,171));
    		
    		
    		leftReset[i].setIcon(left[i].getIcon());
    		leftReset[i].setIdentifier(left[i].getIdentifier());
    		
    		rightReset[i] = new Tile();
    		rightReset[i].setPreferredSize(size);
    		rightReset[i].setForeground(Color.BLUE);
    		
    		
    		rightReset[i].setIcon(right[i].getIcon());
    		rightReset[i].setIdentifier(right[i].getIdentifier());
    		
		}
		
		//Rotate the images in the left and right tile arrays
		rotateL();
		rotateR();
		
		
	}
	//++++++++++++++++++++++++++++++++++++++++++
	
	
	
	public void reset()
	{
		for(int i = 0; i<left.length; i++)
		{
			//reset but maintain old location
			left[i] = leftReset[i];
    		right[i] = rightReset[i];
		}
	}
	//++++++++++++++++++++++++++++++++++++++++++
	
	
	/**
	 * This ensures that only one "master" version of each array exists.
	 * Part of the problem of previous iterations was that because the majority of 
	 * this was done through the constructor you would end up with 8 differently shuffled arrays riddled
	 * with possible duplicate images, or missing images.  this way however the program can still instantiate the
	 * TileGrid array but i allows it the freedom of only actually filling one version the TileGrid i.e. the master grid
	 * This way all subsequent grids get their data from the master grid and there are no issues.  This is also why
	 * the constructor does not actually call the fill() method.
	 */
	public void instantiate()
	{
		
		left = new Tile[8];
		right = new Tile[8];
		tiles = new Tile[16];
		solution = new Tile[16];
		leftReset = new Tile[8];
		rightReset = new Tile[8];
		vanilla = new Color(243,229,171);
		size = new Dimension(80,80);
		
	}
	
	//++++++++++++++++++++++++++++++++++++++++++
	
	public void open() 
	{
		int dflt = JOptionPane.showOptionDialog(
				null, "Load Default Maze?", "Load", JOptionPane.YES_NO_OPTION, 
				JOptionPane.QUESTION_MESSAGE, null, null, "Yes");
		
		
		URL url = getClass().getResource("/mazeData/default.mze");
		String path = null;
		
		File maze = null;
		try {
			maze = new File(url.toURI());
		} catch (URISyntaxException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		
		
		if(dflt == 0)
		{
			file = new FileIn(maze);
			img = new Maze(file.getImage());
		}
		else
		{
			path = JOptionPane.showInputDialog("Please enter a file path...");
			try {
				file = new FileIn(path);
				img = new Maze(file.getImage());
			} catch (FileNotFoundException e) {}
		}
		
	}

	
	public void rotateL()
	{
		int i = 0;
		
		//modifier to rotate 90/180/270/360 degrees 
		int rotation =  ThreadLocalRandom.current().nextInt(1, 4 + 1); 
		
		while(i<left.length)
		{
			int width = left[i].getIcon().getIconWidth();
			int height = left[i].getIcon().getIconHeight();
			{
				BufferedImage bimage = new BufferedImage(width,height,BufferedImage.TYPE_INT_RGB);
				Graphics g = bimage.createGraphics();
				// paint the Icon to the BufferedImage.
				left[i].getIcon().paintIcon(null, g, 0,0);
				g.dispose();

				AffineTransform rotate = new AffineTransform();
				rotate.rotate(Math.PI / 2, width / 2, height / 2);
				AffineTransformOp scaleOp = new AffineTransformOp(
				        rotate, AffineTransformOp.TYPE_BILINEAR);
				
				bimage = scaleOp.filter(bimage, null);
	            ImageIcon icon = new ImageIcon(bimage);
	            left[i].setIcon(icon);
	            leftReset[i].setIcon(icon);
				
			}
		
			rotation =  ThreadLocalRandom.current().nextInt(1, 4 + 1); 
			i++;
			
		}
	}
	//++++++++++++++++++++++++++++++++++++++++++
	
	
	
	public void rotateR()
	{
		int i = 0;
		
		//modifier to rotate 90/180/270/360 degrees 
		int rotation =  ThreadLocalRandom.current().nextInt(1, 4 + 1); 
		
		
		while(i<right.length)
		{
			int width = right[i].getIcon().getIconWidth();
			int height = right[i].getIcon().getIconHeight();
			
			{
				BufferedImage bimage = new BufferedImage(width,height,BufferedImage.TYPE_INT_RGB);
				Graphics g = bimage.createGraphics();
				// paint the Icon to the BufferedImage.
				right[i].getIcon().paintIcon(null, g, 0,0);
				g.dispose();

				AffineTransform rotate = new AffineTransform();
				rotate.rotate((Math.PI / 2)*rotation, width / 2, height / 2);
				AffineTransformOp scaleOp = new AffineTransformOp(
				        rotate, AffineTransformOp.TYPE_BILINEAR);
				
				bimage = scaleOp.filter(bimage, null);
	            ImageIcon icon = new ImageIcon(bimage);
	            right[i].setIcon(icon);
	            rightReset[i].setIcon(icon);
				
			}
			
			rotation =  ThreadLocalRandom.current().nextInt(1, 4 + 1); 
			i++;
			
		}
	}
	//++++++++++++++++++++++++++++++++++++++++++
	
	
	
	public void setSolve() 
	{
		//SetUp for Solution:
    	
    	for(int i = 0; i<solution.length; i++)
    	{
    		solution[i] = new Tile();
    		solution[i].setPreferredSize(new Dimension(80,80));
    		solution[i].setIcon(img.getUnshuffled(i));
    		solution[i].setIdentifier("Tile_" + (i + 1)); 
    
    	}
    
    }
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	
	
	
	//Bunch of get Methods plus reset method
	
	//ResetR is random reset
	public void resetR() { fill(); } //For Clarification Purposes I know its redundant
	
	public Tile[] getLeft() { return left; }
	public Tile[] getRight() { return right; }
	public Tile[] getResetR() { return rightReset; }
	public Tile[] getResetL() { return leftReset; }
	public Tile[] getSol() { return solution; }
	
	
	
	
}
