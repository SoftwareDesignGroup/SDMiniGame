import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JPanel;

public class TileGrid extends JPanel
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private GridLayout layout = new GridLayout(8,1);
	private JPanel grid;
	private Maze img = new Maze();
	
	
	private Tile[] tiles, left, right, rightR, leftR;
	
	
	private Color vanilla ;
	private Dimension size;
	//*****************************
	
	
	
	public TileGrid()
	{
		grid = new JPanel(layout);
		fill();
	}
	//++++++++++++++++++++++++++++++++
	
	
	public void fill()
	{
		left = new Tile[8];
		right = new Tile[8];
		tiles = new Tile[16];
		leftR = new Tile[8];
		rightR = new Tile[8];
		vanilla = new Color(243,229,171);
		size = new Dimension(80,80);
		
		
		//Fill array
		for(int i = 0; i<tiles.length; i++)
		{
			tiles[i] = new Tile();
    		tiles[i].setPreferredSize(size);
    		tiles[i].setForeground(new Color(243,229,171));
    		
    		
    		tiles[i].setIcon(img.getImages(i));
    		tiles[i].setIdentifier("Tile_" + (i + 1));
		}
		
		
		//Shuffle Array and Split it into 2
		List<Tile> temp; 
		temp = Arrays.asList(tiles);
		Collections.shuffle(temp);
		tiles = (Tile[])temp.toArray();
		

		System.arraycopy(tiles, 0, left, 0, left.length);
		System.arraycopy(tiles, right.length, right, 0, right.length);
		
		
		//Set number of buttons without them being all shuffled
		for(int  i = 0; i<left.length; i++)
		{
			left[i].setText("#"+(i+1));
    		left[i].setHorizontalTextPosition(JButton.CENTER);
    		left[i].setVerticalTextPosition(JButton.CENTER);
    		right[i].setText("#"+(i+9));
    		right[i].setHorizontalTextPosition(JButton.CENTER);
    		right[i].setVerticalTextPosition(JButton.CENTER);
    		
    		//set up for masters
    		leftR[i] = new Tile();
    		leftR[i].setPreferredSize(size);
    		leftR[i].setForeground(new Color(243,229,171));
    		
    		
    		leftR[i].setIcon(left[i].getIcon());
    		leftR[i].setIdentifier(left[i].getIdentifier());
    		
    		rightR[i] = new Tile();
    		rightR[i].setPreferredSize(size);
    		rightR[i].setForeground(new Color(243,229,171));
    		
    		
    		rightR[i].setIcon(right[i].getIcon());
    		rightR[i].setIdentifier(right[i].getIdentifier());
    		
		}
		
		
	}
	
	public void reset()
	{
		for(int i = 0; i<left.length; i++)
		{
			//reset
			left[i] = leftR[i];
    		right[i] = rightR[i];
		}
	}
	
	//++++++++++++++++++++++++++++++++++++++++++
	
	
	//Bunch of get Methods plus reset method
	
	//ResetR is random
	public void resetR() { fill(); } //For Clarification Purposes I know its redundant
	
	public Tile[] getLeft() { return left; }
	public Tile[] getRight() { return right; }
	//public Tile[] getLeftR() { return leftR; }
	//public Tile[] getRightR() { return rightR; }
	
	
	
}
