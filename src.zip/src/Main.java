@SuppressWarnings("null")
public class Main
{
	@SuppressWarnings("unused")
	public static void main(String[] args)
	{
		
		MiniGame minigame = new MiniGame();	
	}
}