import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

public class MiniGame extends Frame implements ActionListener, MouseListener
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 
	 */
	
	
	
	private GameBoard gb;     //Where the Tiles will end up
	private TileGrid tgridL;  //Where the tiles start
	private TileGrid tgridR; 
	private TileGrid solution;  //For solution
	private TileGrid master;  //For Reset and to ensure no duplicates
	
	
	private NewGame newgame;  //Buttons
	private Quit quit;
	private JButton reset;
	private JButton check;
	private JButton solve;
	private JButton selector;
	private JButton menuButton;  //Main menu
	private JButton newBgrnd;
	private JPanel bgrid; //Where the buttons Are
	
	
	private JFrame window;       //Main Window
	private Tile tilesToSwap[];  //For Swap
	private Color vanilla;       //Color for Borders
	private Timer timer;		//Time How long it takes to solve the puzzle
	private JPanel contentPane;  //Display Area
	
	
	
	private Dimension buttonsize;    //Button Dimensions
	private Dimension buttongridDim;  //Button Grid Size
	private Dimension tilegridDim;    //Tile Grid Size
	private Dimension gameboardDim;   // Game Board Size
	
	
	private int windowL;  //window length
	private int windowH;  //window height
	private int r; //counter for reset
	//****************************************************
	
	/**
	 * Initialises the Game Window
	 * 
	 */
	
	
	public MiniGame()
	{
		
		vanilla = new Color(243,229,171);
		tilesToSwap = new Tile[2];
		timer = new Timer();
		
		//r = 2; //Counter for reset
		
		//Dimension Set Up
		buttonsize = new Dimension(125,50);
		buttongridDim = new Dimension(0,55);
		tilegridDim = new Dimension(175,0);
		gameboardDim = new Dimension(317,317);
		windowL = 1000;
		windowH =1000;
		//windowH = 650;
	
		//-----------------------------------------------------
		
		
		
		//New Game Button SetUp
		
		newgame = new NewGame();
		newgame.setPreferredSize(buttonsize);
		newgame.setText("New Game");
		newgame.addActionListener(newgame);
		newgame.setBorder(BorderFactory.createLineBorder(Color.BLACK,2,true));
		newgame.setForeground(Color.BLACK);
		
		//newgame.setBorder(BorderFactory.createLineBorder(vanilla,2,true));
		//newgame.setForeground(vanilla);
		//-----------------------------------------------------		
		
		
		//Quit Button SetUp
		
		quit = new Quit();
		quit.setPreferredSize(buttonsize);
		quit.setText("Quit");
		quit.addActionListener(quit);
		quit.setBorder(BorderFactory.createLineBorder(Color.BLACK,2,true));
		quit.setForeground(Color.BLACK);
		
		//quit.setBorder(BorderFactory.createLineBorder(vanilla,2,true));
		//quit.setForeground(vanilla);
		//-----------------------------------------------------		
		
		
		//Reset Button SetUp
		
		reset = new JButton();
		reset.setPreferredSize(buttonsize);
		reset.setText("Reset");		
		reset.addActionListener(this);
		reset.setBorder(BorderFactory.createLineBorder(Color.BLACK,2,true));
		reset.setForeground(Color.BLACK);
		
		//reset.setBorder(BorderFactory.createLineBorder(vanilla,2,true));
		//reset.setForeground(vanilla);
		//-----------------------------------------------------	
		
		
		//Solve Button SetUp
		
		solve = new JButton();
		solve.setPreferredSize(buttonsize);
		solve.setText("Solve");
		solve.addActionListener(this);
		solve.setBorder(BorderFactory.createLineBorder(Color.BLACK,2,true));
		solve.setForeground(Color.BLACK);
		
		//solve.setBorder(BorderFactory.createLineBorder(vanilla,2,true));
		//solve.setForeground(vanilla);
		//-----------------------------------------------------
		
		
		//Check Button SetUp
		
		check = new JButton();
		check.setPreferredSize(buttonsize);
		check.setText("Check");
		check.addActionListener(this);
		check.setBorder(BorderFactory.createLineBorder(Color.BLACK,2,true));
		check.setForeground(Color.BLACK);
		
		//check.setBorder(BorderFactory.createLineBorder(vanilla,2,true));
		//check.setForeground(vanilla);
		//-----------------------------------------------------
		
		
		//ImgSelect Button SetUp
		
		selector = new JButton();
		selector.setPreferredSize(buttonsize);
		selector.setText("New Image - UC");
		selector.addActionListener(this);
		selector.setBorder(BorderFactory.createLineBorder(Color.BLACK,2,true));
		selector.setForeground(Color.BLACK);
		
		//selector.setBorder(BorderFactory.createLineBorder(vanilla,2,true));
		//selector.setForeground(vanilla);
		//-----------------------------------------------------
		
		
		//Menu Button SetUp
		
		menuButton = new JButton();
		menuButton.setPreferredSize(buttonsize);
		menuButton.setText("Menu");
		menuButton.addActionListener(this);
		menuButton.setBorder(BorderFactory.createLineBorder(Color.BLACK,2,true));
		menuButton.setForeground(Color.BLACK);
		
		//menuButton.setBorder(BorderFactory.createLineBorder(vanilla,2,true));
		//menuButton.setForeground(vanilla);
		//-----------------------------------------------------
		
		
		//BackGround Changer Button SetUp
		
		newBgrnd = new JButton();
		newBgrnd.setPreferredSize(buttonsize);
		newBgrnd.setText("New Background");
		newBgrnd.addActionListener(this);
		newBgrnd.setBorder(BorderFactory.createLineBorder(Color.BLACK,2,true));
		newBgrnd.setForeground(Color.BLACK);
		
		//newBgrnd.setBorder(BorderFactory.createLineBorder(vanilla,2,true));
		//newBgrnd.setForeground(vanilla);
		//-----------------------------------------------------
		

		//Button Grid SetUp
		
		bgrid = new JPanel();
		bgrid.setLayout(new GridBagLayout());
		bgrid.setPreferredSize(buttongridDim);
		GridBagConstraints c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 0;
		c.insets = new Insets(0,15,5,0);
		bgrid.add(newgame,c);
		c.gridx = 1;
		bgrid.add(quit,c);
		c.gridx = 2;
		bgrid.add(reset,c);
		
		//c.gridx = 3;
		//bgrid.add(solve,c);
		//c.gridx = 4;
		//bgrid.add(check,c);
		//c.gridx = 5;
		//bgrid.add(selector,c);
		//c.gridx = 6;
		//bgrid.add(menuButton,c);
		
		bgrid.setOpaque(false);
		
		insertGameTiles();
		//-----------------------------------------------------
		
		
		contentPane = new JPanel(new GridBagLayout()); //Set Display Area Background Image
		/*
				{
					public void paintComponent(Graphics g)
					{
						Image img = Toolkit.getDefaultToolkit().getImage(
								Main.class.getResource("/backgrounds/default.jpg"));
						g.drawImage(img, 0, 0, this.getWidth(), this.getHeight(),this);
								
					}
				};
		//-----------------------------------------------------		
		 * 
		 */
		
		
		//Main Window Set Up
		
		window = new JFrame();
		window.setSize(windowL,windowH);
		window.add(contentPane);
		
		windowSetUp(contentPane);
		
		window.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		window.setVisible(true);
		
	}
	
	
	
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	
	
	
	public void swapTiles(Tile t1, Tile t2)
	{
		Color original = UIManager.getColor ( "Panel.background" );
		
		
		/**	Warn user of illegal move if attempting to place tile on top of tile
			In my humble opinion this isn't the greatest way to handle such an occurrence
			I think simply interchanging the two tiles is a better idea but specifications are specifications.
		 * 
		 */
		if( t2.getIcon() != null)
		{
			contentPane.setBackground(Color.RED);
			t1.setBorder(BorderFactory.createLineBorder(Color.BLACK,2));
			//contentPane.setBackground(Color.WHITE);
			return;
		}

		contentPane.setBackground(original);
		
		if(t1 != t2) //If tile to be swapped is same cancel swap
		{
			
			//Swap Tile Identifiers
			if(t1.getIdentifier() != null)
			{
				String x;
				x = t1.getIdentifier();
				t1.setIdentifier(t2.getIdentifier());
				t2.setIdentifier(x);
			}
			//-----------------------------------------------------
		
	
			ImageIcon y = new ImageIcon();  //Swap tile Icons
			y = (ImageIcon) t1.getIcon();
			t1.setIcon(t2.getIcon());
			t2.setIcon(y);
			t1.setBorder(BorderFactory.createLineBorder(Color.BLACK,2));
			
			
			//Remove tile border
			if(t2.getLoc()==false)
			{
				t2.setBorder(BorderFactory.createEmptyBorder());
				
			}
			//-----------------------------------------------------
			
			
			/*
			 * t1.setBorder(BorderFactory.createLineBorder(vanilla,2,true));
			 * 
			 * 
			 * 
			 * // Maintain empty Borders for GameBoard tiles only
			 * 
			for(int i = 0; i<gb.getTiles().length; i++)
			{
				gb.getTiles()[i].setBorder(BorderFactory.createEmptyBorder()); 
			}
			//-----------------------------------------------------
			 * 
			 */
			
			
		}
		
		else
		{
			
			t1.setBorder(BorderFactory.createLineBorder(Color.BLACK,2));
	
			
			
			/*
			 * t1.setBorder(BorderFactory.createLineBorder(vanilla,2,true));
			 * 
			 * 
			 * // Maintain empty Borders for GameBoard tiles only
			 * 
			for(int i = 0; i<gb.getTiles().length; i++)
			{
				gb.getTiles()[i].setBorder(BorderFactory.createEmptyBorder());
			}
			//-----------------------------------------------------
			 * 
			 */
			
			
		}
		
	}
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	
	
	
	public  void actionPerformed(ActionEvent e)
	{
		
		/**
		 * To change reset behaviour from 'reset to old position' to 'reset to random Position'
		 * follow these steps:
		 * 
		 * 1. uncomment master.resetR()
		 * 
		 * 2. uncomment if(r%2.....)
		 * 
		 * 3. uncomment whole else if( r%2 == ...)
		 * 
		 * 4. comment out master.reset()
		 * 
		 */
		
		
		
		if(e.getActionCommand() == "Reset")
		{
			master.reset();
			timer = null;
			timer = new Timer();
			//master.resetR();
			//-----------------------------------------------------
			
			
			//if(r%2 != 0 || r==0) //On every odd press L->L and R->R for added randomness
			{
				for(int i=0; i<tgridL.getLeft().length; i++)
				{
					tgridL.getLeft()[i].setIcon(master.getLeft()[i].getIcon());
					tgridR.getRight()[i].setIcon(master.getRight()[i].getIcon());
					
					//Reset Borders on tiles in case any disappeared
					tgridL.getLeft()[i].setBorder(BorderFactory.createLineBorder(Color.BLACK,2));
					tgridR.getRight()[i].setBorder(BorderFactory.createLineBorder(Color.BLACK,2));
					
				}
				
			}
			//--------------------------------------------------------------------------------------
			
			
			
			/*Below is for random reset
			/*
			else if(r%2 == 0) //On every even press switch L->R and R->L for added randomness
			{
				
				for(int i=0; i<tgridL.getLeft().length; i++)
				{
					tgridL.getLeft()[i].setIcon(master.getRight()[i].getIcon());
					tgridR.getRight()[i].setIcon(master.getLeft()[i].getIcon());
				}
				

			}
			
			//-----------------------------------------------------
			 * 
			 */
			
			
			for(int i=0; i<gb.getTiles().length; i++) //set board icons to null for reset
			{
				gb.getTiles()[i].setIcon(null);
				gb.getTiles()[i].setIdentifier(null);
				gb.getTiles()[i].setBorder(BorderFactory.createLineBorder(Color.BLACK,2));
			}
			//-----------------------------------------------------
			
			
			JOptionPane.showMessageDialog(null, "Game has been reset!");
			
			//r++;
			
			return;
		}
		//--------------------------------------------------------------------------------------
		
		
		
		
		else if(e.getActionCommand() == "Solve")
		{
			
			
			
			for(int i = 0; i < tgridL.getLeft().length; i++)
			{
				tgridL.getLeft()[i].setIcon(null); //Remove Icons from TileGrids
				tgridR.getRight()[i].setIcon(null);
				tgridL.getLeft()[i].setBorder(BorderFactory.createLineBorder(Color.BLACK,2));
				tgridR.getRight()[i].setBorder(BorderFactory.createLineBorder(Color.BLACK,2));
				
				//tgridL.getLeft()[i].setBorder(BorderFactory.createLineBorder(vanilla,2,true));
				//tgridR.getRight()[i].setBorder(BorderFactory.createLineBorder(vanilla,2,true));
		
			}
			//-----------------------------------------------------
			
			
			
			for(int i=0; i<gb.getTiles().length; i++) //get/set winning position
			{
				gb.getTiles()[i].setIcon(solution.getSol()[i].getIcon());
				gb.getTiles()[i].setIdentifier(solution.getSol()[i].getIdentifier());
			}
			//-----------------------------------------------------
			
			
			
			for(int i=0; i<gb.getTiles().length; i++)
			{
				//Remove Grid Lines
				gb.getTiles()[i].setBorder(BorderFactory.createEmptyBorder());
			}
			
			
			gameWon();  //Check
		}
		//--------------------------------------------------------------------------------------
		
		
		
		
		//This may end up being useless
		else if(e.getActionCommand() == "Check")  //In case you want to check mid way or 
			//if you made what looks like the correct maze but arent sure
		{	
			gameWon();
		}
		//--------------------------------------------------------------------------------------
		
		
		/*
		 * Below is for "I want a game that doesn't look like a calculator" Version
		 *
		 *
		 *
		 *
		 *
		 *
		 *
		else if(e.getActionCommand() == "New Image-UC")  //Under Construction
		{
			return;
		}
		//--------------------------------------------------------------------------------------
		
		
		
		else if(e.getActionCommand() == "New Background")
		{
			String name;
			name = JOptionPane.showInputDialog("Please Enter Background Name:" + "\n" + "(Enter default to revert)");
			contentPane = new JPanel(new GridBagLayout())  //Set Display Area Background Image
					{
						public void paintComponent(Graphics g)
						{
							Image img = Toolkit.getDefaultToolkit().getImage(
									MiniGame.class.getResource("/backgrounds/"+name+".jpg"));
							g.drawImage(img, 0, 0, this.getWidth(), this.getHeight(),this);
									
						}
					};
			windowSetUp(contentPane);
			window.add(contentPane);
			window.setVisible(true);
			
		}
		
		
		
		
		
		else if(e.getActionCommand() == "Menu")
		{
			JDialog menu = new JDialog();
			menu.setSize(325, 375);
			JPanel menuPane = new JPanel(new GridBagLayout())  
					{
						public void paintComponent(Graphics g)  //Set menu Background Image
						{
							Image img = Toolkit.getDefaultToolkit().getImage(
									MiniGame.class.getResource("/backgrounds/bg.jpg"));
							g.drawImage(img, 0, 0, menu.getWidth(), menu.getHeight(), menu);
									
						}
					};
			
				
			GridBagConstraints c = new GridBagConstraints();
			c.insets = new Insets(0,0,0,0);
			c.gridx = 2;
			c.gridy = 1;
			menuPane.add(newgame,c);
			
			c.insets = new Insets(15,0,0,0);
			c.gridx = 2;
			c.gridy = 2;
			menuPane.add(selector,c);
			
			c.insets = new Insets(15,0,0,0);
			c.gridx = 2;
			c.gridy = 3;
			menuPane.add(newBgrnd,c);
			
			c.insets = new Insets(15,0,0,0);
			c.gridx = 2;
			c.gridy = 4;
			
			menuPane.add(quit,c);
			menu.getRootPane().setOpaque(false);
			menu.setLocationRelativeTo(window);
			menu.add(menuPane);
			menu.setVisible(true);
		}
		//--------------------------------------------------------------------------------------
		 * 
		 */
		
		
		
		else  //You are working with Tiles so start swapping
		{
			if(tilesToSwap[0] == null)
			{
				Border border = new LineBorder(Color.blue, 3);  //Highlight Tile to be swapped
				tilesToSwap[0] = (Tile) e.getSource();
				tilesToSwap[0].setBorder(border);
			}
			
			
			else
			{
				tilesToSwap[1] = (Tile) e.getSource();
				swapTiles(tilesToSwap[0], tilesToSwap[1]);
				tilesToSwap[0] = null;
				tilesToSwap[1] = null;
				
			}
			
			
			//Automatic Win Check
			
			boolean isNull = true;  //Be sure that the game board tiles actually have icons before doing win check
			
			for(int i=0 ; i<gb.getTiles().length; i++)
			{
				
				//If game board tile Icon is null break the loop and DO NOT check for win
				if(gb.getTiles()[i].getIcon() == null)
				{
					isNull = true;
					break;
				}
				else
				{
					//If game board tile Icon is NOT null set to false but continue loop to check all Tiles
					isNull = false;
				}
			}
			
			if(isNull == false)
			{
				//if all tiles have icons check if game has been won
				gameWon();
			}
		}
		//--------------------------------------------------------------------------------------
		
		
		
	}
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	
	
	@Override
	public void mouseClicked(MouseEvent e) 
	{
		
		//Rotate Image on mouse Right Click
		
		int width = ((Tile) e.getSource()).getIcon().getIconWidth();
		int height = ((Tile) e.getSource()).getIcon().getIconHeight();
		
		if(SwingUtilities.isRightMouseButton(e))
		{
			BufferedImage bimage = new BufferedImage(width,height,BufferedImage.TYPE_INT_RGB);
			Graphics g = bimage.createGraphics();
			
			// paint the Icon to the BufferedImage.
			((Tile) e.getSource()).getIcon().paintIcon(null, g, 0,0);
			g.dispose();

			AffineTransform rotate = new AffineTransform();
			rotate.rotate(Math.PI / 2, width / 2, height / 2);
			AffineTransformOp scaleOp = new AffineTransformOp(rotate, AffineTransformOp.TYPE_BILINEAR);
			
			bimage = scaleOp.filter(bimage, null);
            ImageIcon icon = new ImageIcon(bimage);
            ((Tile) e.getSource()).setIcon(icon);
			
		}
	}
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	
	
	
	//check if game has been won
	public void gameWon()
	{
		if(gb.gameWon())
		{
			JOptionPane.showMessageDialog(null, "You Win!"+"\n"+"Your Time Was: "+ "\n"+ timer.getTime());
		}
		
		else
		{
			JOptionPane.showMessageDialog(null, "Wrong!");
		}

	}
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	
	
	
	
	public void insertGameTiles()
	{
		tgridL = new TileGrid();
		tgridL.instantiate();
		tgridL.setPreferredSize(tilegridDim);
		tgridL.setOpaque(false);
		//------------------------------------------------------
		
		
		tgridR = new TileGrid();
		tgridR.instantiate();
		tgridR.setPreferredSize(tilegridDim);
		tgridR.setOpaque(false);
	  //------------------------------------------------------
		
		
		solution = new TileGrid();
		solution.instantiate();
	  //------------------------------------------------------
		
		
		master = new TileGrid();
		master.fill();
	 //------------------------------------------------------
		
		
	    
		gb = new GameBoard();
		gb.setPreferredSize(gameboardDim);
		gb.setLayout(new GridBagLayout());
		gb.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
		gb.setOpaque(false);
		
		//gb.setBorder(BorderFactory.createLineBorder(vanilla, 2));
		//------------------------------------------------------
		
		
	
		//Tgrid0_7 setUp
		
		for(int i = 0; i < 8; i++) //add tiles to grid
		{
			tgridL.getLeft()[i] = master.getLeft()[i];
			tgridL.getLeft()[i].addActionListener(this);
			tgridL.getLeft()[i].addMouseListener(this);
			tgridL.getLeft()[i].setLoc(true);
			tgridL.add(tgridL.getLeft()[i]);
		}
		//------------------------------------------------------
		
		
		//Tgrid8_16 set Up
		
		for(int i = 0; i < 8; i++)  //add tiles to grid
		{
			tgridR.getRight()[i] = master.getRight()[i];
			tgridR.getRight()[i].addActionListener(this);
			tgridR.getRight()[i].addMouseListener(this);
			tgridR.getRight()[i].setLoc(true);
			tgridR.add(tgridR.getRight()[i]);
		}
		//------------------------------------------------------
		
		
		//Solution  Set-Up
		
		for(int i = 0; i < 16; i++)  //add tiles to grid
		{
			solution.getSol()[i] = master.getSol()[i];
		}
		//------------------------------------------------------
		
		
		
		//Game Board SetUp
		
		GameBoardSetUp();
		
		//------------------------------------------------------
		
		
		//Set Border For Tiles
		 
		for(int i = 0; i< tgridL.getLeft().length; i++)
		{
			tgridL.getLeft()[i].setBorder(BorderFactory.createLineBorder(Color.BLACK,2));
			tgridR.getRight()[i].setBorder(BorderFactory.createLineBorder(Color.BLACK,2));
			
			
			//tgridL.getLeft()[i].setBorder(BorderFactory.createLineBorder(vanilla,2,true));
			//tgridR.getRight()[i].setBorder(BorderFactory.createLineBorder(vanilla,2,true));
		}
		
	}
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	
	
	
	public void windowSetUp(JComponent component)
	{
		GridBagConstraints c = new GridBagConstraints();
		//------------------------------------------------------
		
		
		c.anchor = GridBagConstraints.CENTER;
		c.weightx = 0.0;
		c.weighty = 0.0;
		c.insets = new Insets(0,295,10,0);
		c.gridx = 2;
		c.gridy = 2;
		c.gridwidth = 1;
		c.gridheight = 1;
		component.add(gb,c);
		//------------------------------------------------------
		
		
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		c.fill = GridBagConstraints.HORIZONTAL;
		c.weightx = 0.0001;
		c.weighty = 0.0001;
		c.ipady = 0;
		c.ipadx = 0;
		c.insets = new Insets(50,0,0,0);
		c.gridx = 1;
		c.gridy = 2;
		c.gridwidth = 3;
		component.add(bgrid,c);
		//------------------------------------------------------
		
		
		c.anchor = GridBagConstraints.LINE_START;
		c.fill = GridBagConstraints.VERTICAL;
		c.gridx = 0;
		
		//c.insets = new Insets(135,10,0,0);   //For 1000 x 650 window size
		
		c.insets = new Insets(220,10,0,0);
		c.weightx = 0.0001;
		c.weighty = 0.0001;
		component.add(tgridL,c);
		//------------------------------------------------------
		
		
		c.anchor = GridBagConstraints.LINE_END;
		c.fill = GridBagConstraints.VERTICAL;
		c.gridx = 3;
		
		//c.insets = new Insets(135,10,0,0);   //For 1000 x 650 window size
		
		c.insets = new Insets(220,0,0,10);
		c.weightx = 0.0001;
		c.weighty = 0.0001;
		component.add(tgridR, c);
		//------------------------------------------------------
		
		
	}
	
	private void GameBoardSetUp()
	{
		GridBagConstraints c = new GridBagConstraints();
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		c.insets = new Insets(0,0,0,0);
		c.ipady = 0;
		c.ipadx = 0;
		c.weightx = 0.0001;
		c.weighty = 0.0001;
		c.gridx = 0;
		c.gridy = 0;
		//------------------------------------------------------
		
		
		for(int i = 0; i < gb.getTiles().length; i++)  //add tiles to board
		{
			gb.getTiles()[i].addActionListener(this);
			gb.getTiles()[i].addMouseListener(this);
			gb.getTiles()[i].setBorder(new LineBorder(Color.BLACK,2));
			//gb.getTiles()[i].setBorder(BorderFactory.createEmptyBorder());
		}
		//------------------------------------------------------
		
		
		
		//I could make a loop for this but I'm Lazy
		{
			gb.add(gb.getTiles()[0],c);
			c.insets = new Insets(0,78,0,0);
			gb.add(gb.getTiles()[1],c);
			c.insets = new Insets(0,155,0,0);
			gb.add(gb.getTiles()[2],c);
			c.insets = new Insets(0,233,0,0);
			gb.add(gb.getTiles()[3],c);
			c.insets = new Insets(78,0,0,0);
			gb.add(gb.getTiles()[4],c);
			c.insets = new Insets(78,78,0,0);
			gb.add(gb.getTiles()[5],c);
			c.insets = new Insets(78,155,0,0);
			gb.add(gb.getTiles()[6],c);
			c.insets = new Insets(78,233,0,0);
			gb.add(gb.getTiles()[7],c);
			c.insets = new Insets(155,0,0,0);
			gb.add(gb.getTiles()[8],c);
			c.insets = new Insets(155,78,0,0);
			gb.add(gb.getTiles()[9],c);
			c.insets = new Insets(155,155,0,0);
			gb.add(gb.getTiles()[10],c);
			c.insets = new Insets(155,233,0,0);
			gb.add(gb.getTiles()[11],c);
			c.insets = new Insets(233,0,0,0);
			gb.add(gb.getTiles()[12],c);
			c.insets = new Insets(233,78,0,0);
			gb.add(gb.getTiles()[13],c);
			c.insets = new Insets(233,155,0,0);
			gb.add(gb.getTiles()[14],c);
			c.insets = new Insets(233,233,0,0);
			gb.add(gb.getTiles()[15],c);
		}
		//------------------------------------------------------
		
	}



	


//These are only here due to implementation of MouseListener
	@Override
	public void mousePressed(MouseEvent e) {}

	@Override
	public void mouseReleased(MouseEvent e) {}

	@Override
	public void mouseEntered(MouseEvent e) {}

	@Override
	public void mouseExited(MouseEvent e) {}
	
}
