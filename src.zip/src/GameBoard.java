import java.awt.*;
import javax.swing.*;



class GameBoard extends JPanel
{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private JPanel board;
	private Tile tiles[];
	private GridBagLayout layout = new GridBagLayout();
	//****************************************************
	
	
	public GameBoard()
	{
		board = new JPanel();
		fillBoard();
	}
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	
	
	
	public void fillBoard()
    {
		tiles = new Tile[16];
		
		
    	for(int i = 0; i < tiles.length; i++)
    	{
    		tiles[i] = new Tile();
    		tiles[i].setPreferredSize(new Dimension(80,80));
    		
    	}
    }
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	
	
	
	public Tile[] getTiles()
	{
		return tiles;
	}
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	
	
	
	public boolean gameWon()  //Check for tile proper location
	{
		boolean won = true;
		for(int i = 0; i < tiles.length; i++)
		{
			if (!tiles[i].getIdentifier().equals("Tile_" + (i + 1)))
				won = false;
		}
		return won;
	}
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	
	
	
	public void print() //For Test Purposes
	{
		for(Tile tile : tiles)
		{
			System.out.print(tile.getIdentifier());
			System.out.println();
		}
	}
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	
	
	
}
