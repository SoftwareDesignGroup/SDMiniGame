
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;




public class Tile extends JButton{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private JButton tile;
	private String identifier; //used to check if the game has been won
	private boolean location = false;  //used to check if tile belongs to Tile Grid or Game Board
	
	public Tile() {tile = new JButton();}
	
	public void setIdentifier(String ident) {identifier = ident;}
	
	public String getIdentifier() {return identifier;}
	
	
	
	//Set to true ONLY IF Tile is IN the TileGrid otherwise False
	public void setLoc(boolean bool){location = bool;}
	public boolean getLoc(){return location;}
	
	public void save(ObjectOutputStream file) throws IOException
	{
		file.writeObject(identifier);
		file.writeObject(this.getIcon());
	}
	
	public void load(ObjectInputStream file) throws ClassNotFoundException, IOException
 	{
		setIdentifier((String) file.readObject());
		this.setIcon((ImageIcon) file.readObject());
 	}

	

}
