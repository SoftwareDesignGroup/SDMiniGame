
import javax.swing.JButton;




public class Tile extends JButton{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private JButton tile;
	private String identifier; //used to check if the game has been won
	private static boolean location = false;  //used to check if tile belongs to Tile Grid or Game Board
	
	public Tile() {tile = new JButton();}
	
	public void setIdentifier(String ident) {identifier = ident;}
	
	public String getIdentifier() {return identifier;}
	
	
	
	//Set to true ONLY IF Tile is IN the TileGrid otherwise False
	public void setLoc(boolean bool){location = bool;}
	public static boolean getLoc(){return location;}

	

}
