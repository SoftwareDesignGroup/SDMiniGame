
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.swing.ImageIcon;
import javax.swing.JButton;




@SuppressWarnings("null")
public class Tile extends JButton{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@SuppressWarnings("unused")
	private JButton tile;
	private String identifier; //used to check if the game has been won
	private boolean location = false;  //used to check if tile belongs to Tile Grid or Game Board
	
	public Tile() {this.tile = new JButton();}
	
	@SuppressWarnings("unqualified-field-access")
	public void setIdentifier(String ident) {identifier = ident;}
	
	@SuppressWarnings("unqualified-field-access")
	public String getIdentifier() {return identifier;}
	
	
	
	//Set to true ONLY IF Tile is IN the GameBoard otherwise False
	public void setLoc(boolean bool){this.location = bool;}
	public boolean isOnBoard(){return this.location;}
	
	@SuppressWarnings("unqualified-field-access")
	public void save(ObjectOutputStream file) throws IOException
	{
		file.writeObject(identifier);
		file.writeObject(this.getIcon());
	}
	
	public void load(ObjectInputStream file) throws ClassNotFoundException, IOException
 	{
		setIdentifier((String) file.readObject());
		this.setIcon((ImageIcon) file.readObject());
 	}


	

}
