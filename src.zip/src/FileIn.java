

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JOptionPane;


public class FileIn
{
	private FileInputStream fileInputStream = null;
	private URL url;
	private File file = null;
	private int numOfChunks;
	private byte[] bFile;
	private byte[][] data;
	private Vector<Integer> lines;
	private Vector<Float> coordinates;
	private Vector tiles;
	private JFrame frame;
	
	private int start;
	private int end;
	private int offsetx;
	private int offsety;
	private int counter;
	private Image image;
	//****************************************************
	
	
	/**
	 * Takes a string as a parameter
	 * 
	 * @param String path
	 * @throws FileNotFoundException
	 */
	
	public FileIn(String path) throws FileNotFoundException
	{
		image = digitize(path);
	}
	//-----------------------------------------------------
	
	/**
	 * Takes a File as a Parameter
	 * 
	 * @param FileMenu file
	 */
	
	public FileIn(File file) 
	{
		image = digitize(file);
	}
	//-----------------------------------------------------
	
	
	

	/**
	 * 
	 * creates and returns an image of the maze generated from the datafile
	 * 
	 * @param FileMenu maze
	 * @return
	 */
	private Image digitize(File maze)
	{
		fileInputStream=null; 
        file = maze;
        
        lines = new Vector();
        tiles = new Vector();
        coordinates = new Vector();
        
        frame = new JFrame();
        frame.setSize(400, 400); 
        frame.setUndecorated(true);
        
      //-----------------------------------------------------
        
		
		//Had to typecast for file length
		 bFile = new byte[(int)file.length()];
		//-----------------------------------------------------
		
		
		
        //Attempt Read File
        try 
        {
            //convert file into array of bytes
        	fileInputStream = new FileInputStream(file);
        	fileInputStream.read(bFile);
        	fileInputStream.close();
	    
	   
        	//Had to typecast for math functions
        	numOfChunks = (int)Math.ceil((double)bFile.length / 4);
        	data = new byte[numOfChunks][];
        
        	data = chunkArray(bFile,4);
        	
        }
        catch(Exception e)
        {
        	e.printStackTrace();

        }
      //-----------------------------------------------------
        
        
        
        
        
        //Read Data and Convert
        for(int i=1; i<data.length; i++)
        {
        	if(data[i][0] == 0)
        	{
        		if(i%2 == 0)
        		{
        			lines.add(Converter.convertToInt(data[i]));
        		}
        		else if( i%2 != 0)
        		{
        			tiles.add(Converter.convertToInt(data[i]));
        		}
        	}
        	else if(data[i][0] != 0)
        	{
        		coordinates.add(Converter.convertToFloat(data[i]));
        	}
        }
      //-----------------------------------------------------
        
        
        //Set up image to draw maze on
        BufferedImage image = new BufferedImage(frame.getWidth(), frame.getHeight(), BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = image.createGraphics();
        g2d.setBackground(Color.WHITE);
        g2d.fillRect(0, 0, image.getWidth(), image.getHeight());
        g2d.setColor(Color.BLACK);
        g2d.setStroke(new BasicStroke(3));
        
      
        //Read In Maze  and draw it to image
        start = 0;
        end = lines.get(0)*4;
        offsetx = 99;
        offsety = 0;
        counter = 1;
        
      //Since first iteration is slightly different it requires a separate loop  
      for(int i=start; i<end; i+=4)
      {
    	  if((i+3)<=(int)lines.get(0)*4)
    	  {
    		  int x1 = Math.round(coordinates.get(i));
    		  int y1 = Math.round(coordinates.get(i+1));
    		  int x2 = Math.round(coordinates.get(i+2));
    		  int y2 = Math.round(coordinates.get(i+3));
    		  g2d.drawLine(x1, y1, x2, y2);
    		  
    	  }
      }
      
      for(int i=1; i<lines.size(); i++)
      {
    	  start = end;
    	  end += (int)lines.get(i)*4;
    	  counter++;
    	  for(int j = start; j<end; j+=4)
    	  {
    		  if((j+3)<=end)
    		  {

    			  int x1 = offsetx+Math.round(coordinates.get(j));
        		  int y1 = offsety+Math.round(coordinates.get(j+1));
        		  int x2 = offsetx+Math.round(coordinates.get(j+2));
        		  int y2 = offsety+Math.round(coordinates.get(j+3));
        		  g2d.drawLine(x1, y1, x2, y2);
    		  }
    	  }
    	  
    	  offsetx += 99;
    	  if(counter%4 == 0)
    	  {
    		  offsety+=99;
    		  offsetx = 0;
    	  }
      }
    
      return image;
      
    //-----------------------------------------------------
      
      
	}
	
	
	/**
	 * 
	 * creates and returns an image of the maze generated from the datafile
	 * 
	 * @param String path
	 * @return
	 */
	private Image digitize(String path)
	{
		fileInputStream=null; 
        //url = Main.class.getResource("/mazeData/"+name+".mze");
        file = null;
        
        lines = new Vector();
        tiles = new Vector();
        coordinates = new Vector();
        
        frame = new JFrame();
        frame.setSize(400, 400); 
        frame.setUndecorated(true);
        
      //-----------------------------------------------------
        
        file = new File(path);
        
        
        /*
        	//Attempt Open File
		try 
		{
			file = new File(url.toURI());
		}
		catch (URISyntaxException e1) 
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
			System.exit(0);
		}
		 * 
		 */
		
		//Had to typecast for file length
		 bFile = new byte[(int)file.length()];
		//-----------------------------------------------------
		
		
		
        //Attempt Read File
        try 
        {
            //convert file into array of bytes
        	fileInputStream = new FileInputStream(file);
        	fileInputStream.read(bFile);
        	fileInputStream.close();
	    
	   
        	//Had to typecast for math functions
        	numOfChunks = (int)Math.ceil((double)bFile.length / 4);
        	data = new byte[numOfChunks][];
        
        	data = chunkArray(bFile,4);
        	
        }
        catch(Exception e)
        {
        	JOptionPane.showMessageDialog(null, "File Does Not Exist!", "Error", JOptionPane.ERROR_MESSAGE);
        	System.exit(0);

        }
      //-----------------------------------------------------
        
        
        
        
        
        //Read Data and Convert
        for(int i=1; i<data.length; i++)
        {
        	if(data[i][0] == 0)
        	{
        		if(i%2 == 0)
        		{
        			lines.add(Converter.convertToInt(data[i]));
        		}
        		else if( i%2 != 0)
        		{
        			tiles.add(Converter.convertToInt(data[i]));
        		}
        	}
        	else if(data[i][0] != 0)
        	{
        		coordinates.add(Converter.convertToFloat(data[i]));
        	}
        }
      //-----------------------------------------------------
        
        
        //Set up image to draw maze on
        BufferedImage image = new BufferedImage(frame.getWidth(), frame.getHeight(), BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = image.createGraphics();
        g2d.setBackground(Color.WHITE);
        g2d.fillRect(0, 0, image.getWidth(), image.getHeight());
        g2d.setColor(Color.BLACK);
        g2d.setStroke(new BasicStroke(3));
        
      
        //Read In Maze  and draw it to image
        start = 0;
        end = lines.get(0)*4;
        offsetx = 99;
        offsety = 0;
        counter = 1;
        
      //Since first iteration is slightly different it requires a separate loop  
      for(int i=start; i<end; i+=4)
      {
    	  if((i+3)<=(int)lines.get(0)*4)
    	  {
    		  int x1 = Math.round(coordinates.get(i));
    		  int y1 = Math.round(coordinates.get(i+1));
    		  int x2 = Math.round(coordinates.get(i+2));
    		  int y2 = Math.round(coordinates.get(i+3));
    		  g2d.drawLine(x1, y1, x2, y2);
    		  
    	  }
      }
      
      for(int i=1; i<lines.size(); i++)
      {
    	  start = end;
    	  end += (int)lines.get(i)*4;
    	  counter++;
    	  for(int j = start; j<end; j+=4)
    	  {
    		  if((j+3)<=end)
    		  {

    			  int x1 = offsetx+Math.round(coordinates.get(j));
        		  int y1 = offsety+Math.round(coordinates.get(j+1));
        		  int x2 = offsetx+Math.round(coordinates.get(j+2));
        		  int y2 = offsety+Math.round(coordinates.get(j+3));
        		  g2d.drawLine(x1, y1, x2, y2);
    		  }
    	  }
    	  
    	  offsetx += 99;
    	  if(counter%4 == 0)
    	  {
    		  offsety+=99;
    		  offsetx = 0;
    	  }
      }
    
     
      //This is throwing a nullpointer exception but for no reason
      // so for now its out but when it does work it does so just fine
      /*
      //Attempt Image Write
      try 
      {
    	  String path = Main.class.getResource("/images/"+name+".jpeg").getPath();
    	  System.out.print(path);
    	  ImageIO.write(image,"jpeg", new File(path));
      } 
      catch (IOException e) 
      {
		// TODO Auto-generated catch block
		e.printStackTrace();
      }
    */
      return image;
      
    //-----------------------------------------------------
      
      
	}
	//-----------------------------------------------------
	
	
	
	
	//Stolen from https://gist.github.com/lesleh/7724554 but changed type to byte instead of int
	//Chunks out array into 4x1 arrays
	 private static byte[][] chunkArray(byte[] array, int chunkSize) 
	 {
	        int numOfChunks = (int)Math.ceil((double)array.length / chunkSize);
	        byte[][] output = new byte[numOfChunks][];

	        for(int i = 0; i < numOfChunks; ++i) {
	            int start = i * chunkSize;
	            int length = Math.min(array.length - start, chunkSize);

	            byte[] temp = new byte[length];
	            System.arraycopy(array, start, temp, 0, length);
	            output[i] = temp;
	        }

	        return output;
	    }
	//-----------------------------------------------------
	 
	 
	 
	 
	 
	 //Print Contents of Vectors
	 //for test
	 private void print()
	 {
		 System.out.print(coordinates);
	      System.out.println();
	      System.out.print(lines);
	      System.out.println();
	      System.out.print(tiles);
	      System.out.println();
	      System.out.print(lines.size());
	      System.out.println();
	      System.out.print(coordinates.size());
	      System.out.println();
	      System.out.print(tiles.size());
	      System.out.println();
	      
	      System.out.println();
	 }
	//-----------------------------------------------------
	 
	 // Get the maze image
	 public Image getImage()
	 {
		 return image;
	 }
	

}
