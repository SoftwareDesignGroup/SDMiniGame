import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JOptionPane;

@SuppressWarnings("null")
public class Save extends JButton implements ActionListener
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static boolean hasBeenSaved = false;

	@Override
	public void actionPerformed(ActionEvent e) 
	{ 
		try 
		{
			save();
		} 
		catch (IOException e1) 
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} 
	}
	//-----------------------------------------------------

	
	
	
	@SuppressWarnings("nls")
	public void save() throws IOException
	{
		URL url = getClass().getResource("/saveFiles/");
		String dir = url.getPath();
		File file = null;
		String path = JOptionPane.showInputDialog("Save As?");
		//-----------------------------------------------------

		
		
		if(path != null){
			file = new File(dir + path + ".sav");
		}
		int dflt = 1;
		
		if(file == null){return;}
		
		while (file.exists() && dflt == 1){
			dflt = JOptionPane.showOptionDialog(null, file + " already exists. Overwrite?", 
					"Filename already exists", JOptionPane.YES_NO_OPTION,
					JOptionPane.QUESTION_MESSAGE, null, null, "yes");
			if (dflt == 1){
				path = JOptionPane.showInputDialog("Save As?");
				if(path != null)
					file = new File(dir + path + ".sav");
				else break;
			}
		}
		//-----------------------------------------------------

		
		
		@SuppressWarnings("resource")
		FileOutputStream saveFile = new FileOutputStream(file);
		@SuppressWarnings("resource")
		ObjectOutputStream save = new ObjectOutputStream(saveFile);
		MiniGame.getLeft().save(save, MiniGame.getRight(), MiniGame.getBoard());
		save.close();
		hasBeenSaved = true;
		
	}
	
	public static boolean getHasBeenSaved(){return hasBeenSaved;}

	
}