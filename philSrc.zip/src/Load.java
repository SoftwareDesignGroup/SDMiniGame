import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JOptionPane;

@SuppressWarnings("null")
public class Load extends JButton implements ActionListener
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	@Override
	public void actionPerformed(ActionEvent e) 
	{ 
		try {
				load();
			} 
			catch (FileNotFoundException e1) 
			{
				JOptionPane.showMessageDialog(null, "File Not Found!");
				return;
			} 		
	}

	
	@SuppressWarnings("nls")
	public void load() throws FileNotFoundException
	{
		
		if(MiniGame.getStateChange() && MiniGame.getWon() == false)  //Ask For save if game state changed
		{
			int choice = JOptionPane.showConfirmDialog(null, "Would You Like To Save First?");
			if(choice == 0)
			{
				Save save = new Save();
				try {
					save.save();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					JOptionPane.showMessageDialog(null, "File Could Not Be Written!");
					return;
				}
			}
			else if(choice == 1){}
			else{return;}
		}
		
		
		//Get Save Files
		URL url = getClass().getResource("/saveFiles/");
		String dir = url.getPath();
		File folder = new File(dir);
		File[] listOfFiles = folder.listFiles();
		int dflt = 1;
		if(MiniGame.checkType())
		{
			int newdflt = JOptionPane.showConfirmDialog(null, "Load New Game Using Default Maze File?");
			if(newdflt == 0){MiniGame.newDefault(); return;}
			else if(newdflt == 1){ dflt = 1;}
			else{return;}
		}
		else
		{
			dflt = JOptionPane.showOptionDialog(null, "Load Default Maze?", "Load", JOptionPane.YES_NO_OPTION,
					JOptionPane.QUESTION_MESSAGE, null, null, "yes");
		}
		

		
		
		//If Want To Load Default Load Default
		if (dflt == 0)
		{
			MiniGame.newDefault();
		}
		
		
		else if(dflt == 1){
			
			
			if (listOfFiles.length != 0)//Check To make Sure saves exist
			{
				
				int choice = JOptionPane.showOptionDialog(null, "Load From Library?\n" + 
			"Selecting No Will Prompt For File Path.", "Load From Where?", JOptionPane.YES_NO_CANCEL_OPTION, 
						JOptionPane.QUESTION_MESSAGE, null, null, null);
				
				
				if(choice == 0)
				{
					File input = (File) JOptionPane.showInputDialog(null, "Choose now...",
				        "List of Load Files", JOptionPane.QUESTION_MESSAGE, null,
				        listOfFiles, listOfFiles[0]);
					String filename = input.getName();
					String extension = filename.substring(filename.lastIndexOf(".") + 1, filename.length());
					
					if(input == null){ return; }//Handle Cancel Button Press
					System.out.println(filename);
					if (extension.equals("mze"))
					{
						URL u = getClass().getResource("/saveFiles/");
						String location = u.getPath() + filename;
						System.out.println(location);
						MiniGame.loadByteFile(location);
					}
					else
					{
						try {
							MiniGame.getLeft().load(input, MiniGame.getRight(), MiniGame.getBoard());
							MiniGame.setState(false);
						} catch (ClassNotFoundException | IOException e) {
							JOptionPane.showMessageDialog(null, "File Not Found!");
							return;
						}
					}
				}
				
				
				
				
				else if(choice == 1)
				{
					String file = JOptionPane.showInputDialog("Please enter full file path...");
					
					if(file == null) { return; } //Handle Cancel Button Press
				
					
					try {
						MiniGame.getLeft().load(new File(file), MiniGame.getRight(), MiniGame.getBoard());
						MiniGame.setState(false);
					} catch (ClassNotFoundException | IOException e) {
						JOptionPane.showMessageDialog(null, "File Not Found!");
						return;
					}
				}
				
			}
			
			
			else if(listOfFiles.length == 0) 
			{
			   String file = JOptionPane.showInputDialog("No Files in Library. Please enter full file path...");
			   
			   if(file == null) { return; }
			   
				File input = new File(file);
				
				try {
					MiniGame.getLeft().load(input, MiniGame.getRight(), MiniGame.getBoard());
					MiniGame.setState(false);
				} catch (ClassNotFoundException | IOException e) {
					JOptionPane.showMessageDialog(null, "File Not Found!");
					return;
				}
			}
		}

	}
}
