import java.util.Calendar;


//Everything in here is pretty Straight Forward

@SuppressWarnings("null")
public class Timer 
{
	private Calendar timer;
	private int start;
	private int stop;
	private int secondS;
	private int secondT;
	
	@SuppressWarnings("unqualified-field-access")
	public Timer()
	{
		//Get Initial time
		timer = Calendar.getInstance();
		secondS = timer.get(Calendar.SECOND);
		timer = Calendar.getInstance();
		start = timer.get(Calendar.MINUTE);
	}
	
	
	@SuppressWarnings({ "unqualified-field-access", "nls" })
	public String getTime()
	{
		
		//Get time
		String time = new String();
		timer = Calendar.getInstance();
		stop = timer.get(Calendar.MINUTE);
		
		
		//For Math
		int diffMin;
		int diffSec;
		
		
		//Remove Negative numbers
		if(stop >= start)
		{
			diffMin = stop-start;
		}
		else
		{
			diffMin = start-stop;
		}
		
		

		if(diffMin > 0)
		{
			//Get time
			timer = Calendar.getInstance();
			secondT = timer.get(Calendar.SECOND);
			
			
			//Remove Neg #'s
			if(secondT >= secondS)
			{
				diffSec = secondT-secondS;
			}
			else
			{
				diffSec = secondS - secondT;
			}
			
			//Print Extra zero if < 10
			if(diffSec < 10)
				time = diffMin + ":" + "0"+ diffSec;
			else
				time = diffMin + ":" + diffSec;
			
			
		}
		
		
		else if( diffMin <=0 ) //Print out just seconds if there is no difference in minutes.
		{
			
			//Get time
			timer = Calendar.getInstance();
			secondT = timer.get(Calendar.SECOND);
			
			
			//Remove Neg #'s
			if(secondT >= secondS)
			{
				diffSec = secondT-secondS;
			}
			else
			{
				diffSec = secondS - secondT;
			}
			
			
			//Print Extra Zero if < 10
			if(diffSec<10)
				time = "0:" + "0"+diffSec;
			else
				time = "0:" + diffSec;
			
		}
		
		
		return time;
		
		
	}
}
