import java.util.Calendar;

public class Timer 
{
	private Calendar timer;
	private int start;
	private int stop;
	private int secondS;
	private int secondT;
	
	public Timer()
	{
		timer = Calendar.getInstance();
		secondS = timer.get(Calendar.SECOND);
		timer = Calendar.getInstance();
		start = timer.get(Calendar.MINUTE);
	}
	
	public String getTime()
	{
		String time = new String();
		timer = Calendar.getInstance();
		stop = timer.get(Calendar.MINUTE);
		int diff;
		int diffSec;
		if(stop >= start)
		{
			diff = stop-start;
		}
		else
		{
			diff = start-stop;
		}
		
		System.out.print(stop);
		if(diff > 0)
		{
			timer = Calendar.getInstance();
			secondT = timer.get(Calendar.SECOND);
			if(secondT >= secondS)
			{
				diffSec = secondT-secondS;
			}
			else
			{
				diffSec = secondS - secondT;
			}
			if(diffSec < 10)
				time = diff + ":" + "0"+ diffSec;
			else
				time = diff + ":" + diffSec;
		}
		else if( diff <=0 )
		{
			timer = Calendar.getInstance();
			secondT = timer.get(Calendar.SECOND);
			if(secondT >= secondS)
			{
				diffSec = secondT-secondS;
			}
			else
			{
				diffSec = secondS - secondT;
			}
			if(diffSec<10)
				time = "0:" + "0"+diffSec;
			else
				time = "0:" + diffSec;
		}
		return time;
	}
}
