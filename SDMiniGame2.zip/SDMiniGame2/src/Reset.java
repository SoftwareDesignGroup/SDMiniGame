import java.awt.Button;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;


public class Reset extends JButton 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private Button bttn;
	
	public Reset()
	{
		bttn = new Button();
		bttn.setEnabled(true);
	}
	
	
}
	
