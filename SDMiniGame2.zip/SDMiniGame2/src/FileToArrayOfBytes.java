import java.io.File;
import java.io.FileInputStream;
import java.nio.ByteBuffer;
import java.util.Vector;

class FileToArrayOfBytes {
	private FileInputStream fileInputStream = null;
	private File file;
	private byte[] bFile;
	private Vector mazeMap;

	public FileToArrayOfBytes() 
	{
		loadFile();
		convertFile();
		createMazeMap();
	}

	public void loadFile() 
	{
		file = new File("C:\\Users\\Phillip\\Downloads\\default.mze");
	}

	public void convertFile() 
	{
		bFile = new byte[(int) file.length()];
		try {
			fileInputStream = new FileInputStream(file);
			fileInputStream.read(bFile);
			fileInputStream.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void createMazeMap() 
	{
		byte[] b = new byte[4];
		mazeMap = new Vector();
		int index = 0;
		int count = 0;
		int lineCount = 0;
		int numLines = 0;
		mazeMap.add(16);
		for (int i = 4; i < bFile.length; i++) {
			b[index] = bFile[i];
			index++;
			if (index % 4 == 0) {
				if (count < 2) {
					mazeMap.add(convertToInt(b));
					numLines = convertToInt(b);
					count++;
				} else if (lineCount < numLines * 4) {
					int num = (int) convertToFloat(b);
					mazeMap.add(num);
					lineCount++;
				} else {
					mazeMap.add(convertToInt(b));
					count = 1;
					lineCount = 0;
				}
				index = 0;
			}
		}
	}

public Vector getMazeMap() 
	{
		return mazeMap;
	}

	public static int convertToInt(byte[] array) 
	{
		ByteBuffer buffer = ByteBuffer.wrap(array);
		return buffer.getInt();
	}

	public static float convertToFloat(byte[] array) 
	{
		ByteBuffer buffer = ByteBuffer.wrap(array);
		return buffer.getFloat();
	}
}