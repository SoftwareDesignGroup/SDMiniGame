import javax.swing.JButton;



public class Tile extends JButton{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private JButton tile;
	private String identifier; //used to check if the game has been won
	
	public Tile() {tile = new JButton();}
	
	public void setIdentifier(String ident) {identifier = ident;}
	
	public String getIdentifier() {return identifier;}

}
