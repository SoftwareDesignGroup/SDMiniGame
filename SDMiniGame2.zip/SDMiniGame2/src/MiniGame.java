import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.util.Date;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

public class MiniGame extends Frame implements ActionListener
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	
	private GameBoard gb;     //Where the Tiles will end up
	private ButtonGrid bgrid; //Where the buttons Are
	private TileGrid tgridL;  //Where the tiles start
	private TileGrid tgridR;  
	private TileGrid master;  //For Reset and to ensure no duplicates
	
	
	private NewGame newgame;  //Buttons
	private Quit quit;
	private Reset reset;
	private Check check;
	private Solve solve;
	private ImgSelect selector;
	
	
	private JFrame window;       //Main Window
	private Tile tilesToSwap[];  //For Swap
	private Color vanilla;       //Color for Borders
	private Timer timer;		//Time How long it takes to solve the puzzle
	
	
	
	private Dimension buttonsize;    //Button Dimensions
	private Dimension buttongridDim;  //Button Grid Size
	private Dimension tilegridDim;    //Tile Grid Size
	private Dimension gameboardDim;   // Game Board Size
	
	
	private int windowL;  //window length
	private int windowH;  //window height
	private int r; //counter for reset
	//****************************************************
	
	
	
	public MiniGame()
	{
		
		vanilla = new Color(243,229,171);
		tilesToSwap = new Tile[2];
		buttonsize = new Dimension(125,50);
		buttongridDim = new Dimension(0,65);
		tilegridDim = new Dimension(175,0);
		gameboardDim = new Dimension(317,317);
		timer = new Timer();
		r = 2;
		windowL = 1000;
		windowH = 650;
		//-----------------------------------------------------
		
		
		
		//New Game Button SetUp
		
		newgame = new NewGame();
		newgame.setPreferredSize(buttonsize);
		newgame.setText("New Game");
		newgame.addActionListener(newgame);
		newgame.setBorder(BorderFactory.createLineBorder(vanilla,2,true));
		newgame.setForeground(Color.black);
		//-----------------------------------------------------		
		
		
		//Quit Button SetUp
		
		quit = new Quit();
		quit.setPreferredSize(buttonsize);
		quit.setText("Quit");
		quit.addActionListener(quit);
		quit.setBorder(BorderFactory.createLineBorder(vanilla,2,true));
		quit.setForeground(Color.black);
		//-----------------------------------------------------		
		
		
		//Reset Button SetUp
		
		reset = new Reset();
		reset.setPreferredSize(buttonsize);
		reset.setText("Reset");		
		reset.addActionListener(this);
		reset.setBorder(BorderFactory.createLineBorder(vanilla,2,true));
		reset.setForeground(Color.black);
		//-----------------------------------------------------	
		
		
		//Solve Button SetUp
		
		solve = new Solve();
		solve.setPreferredSize(buttonsize);
		solve.setText("Solve");
		solve.addActionListener(this);
		solve.setBorder(BorderFactory.createLineBorder(vanilla,2,true));
		solve.setForeground(Color.black);
		//-----------------------------------------------------
		
		
		//Check Button SetUp
		
		check = new Check();
		check.setPreferredSize(buttonsize);
		check.setText("Check");
		check.addActionListener(this);
		check.setBorder(BorderFactory.createLineBorder(vanilla,2,true));
		check.setForeground(Color.black);
		//-----------------------------------------------------
		
		
		//ImgSelect Button SetUp
		
		selector = new ImgSelect();
		selector.setPreferredSize(buttonsize);
		selector.setText("New Image - UC");
		selector.addActionListener(selector);
		selector.setBorder(BorderFactory.createLineBorder(vanilla,2,true));
		selector.setForeground(Color.black);
		//-----------------------------------------------------
		


		//Button Grid SetUp
		
		bgrid = new ButtonGrid();
		bgrid.setPreferredSize(buttongridDim);
		bgrid.add(newgame).setLocation(1, 1);
		bgrid.add(reset).setLocation(1, 2);
		bgrid.add(solve).setLocation(1,3);
		bgrid.add(check).setLocation(1, 5);
		bgrid.add(selector).setLocation(1,4);
		bgrid.add(quit).setLocation(1,6);
		bgrid.setOpaque(false);
		
		insertGameTiles();
		//-----------------------------------------------------
		
		
		JPanel contentPane;
		contentPane = new JPanel(new GridBagLayout())  //Set Background Image
				{
					public void paintComponent(Graphics g)
					{
						Image img = Toolkit.getDefaultToolkit().getImage(
								MiniGame.class.getResource("/backgrounds/bg4.jpg"));
						g.drawImage(img, 0, 0, this.getWidth(), this.getHeight(),this);
								
					}
				};
		//-----------------------------------------------------		
		
		
		//Main Window Set Up
		
		window = new JFrame();
		window.setSize(windowL,windowH);
		window.add(contentPane);
		
		windowSetUp(contentPane);
		
		window.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		window.setVisible(true);
		
	}
	
	
	
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	
	
	
	public void swapTiles(Tile t1, Tile t2)
	{
		if(t1 != t2 && ((t1.getIdentifier() != null) || (t2.getIdentifier() != null))) //If tile to be swapped is same cancel swap
		{
			//Swap Tile Identifiers
			String x;
			x = t1.getIdentifier();
			t1.setIdentifier(t2.getIdentifier());
			t2.setIdentifier(x);
			//-----------------------------------------------------
		
	
			ImageIcon y = new ImageIcon();  //Swap tile Icons
			y = (ImageIcon) t1.getIcon();
			t1.setIcon(t2.getIcon());
			t2.setIcon(y);
			t1.setBorder(BorderFactory.createLineBorder(vanilla,2,true));
			//-----------------------------------------------------
			
			
			for(int i = 0; i<gb.getTiles().length; i++)
			{
				// Maintain empty Borders for GameBoard tiles only
				gb.getTiles()[i].setBorder(BorderFactory.createEmptyBorder()); 
			}
			//-----------------------------------------------------
			
			
		}
		
		else
		{
			t1.setBorder(BorderFactory.createLineBorder(vanilla,2,true));
			//-----------------------------------------------------
			
			
			for(int i = 0; i<gb.getTiles().length; i++)
			{
				// Maintain empty Borders for GameBoard tiles only
				gb.getTiles()[i].setBorder(BorderFactory.createEmptyBorder());
			}
			//-----------------------------------------------------
			
			
		}
		
	}
	
	
	
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	
	
	
	public  void actionPerformed(ActionEvent e)
	{
		if(e.getActionCommand() == "Reset")
		{
			master.reset();
			timer = null;
			timer = new Timer();
			//-----------------------------------------------------
			
			
			if(r%2 != 0 || r==0) //On every odd press L->L and R->R for added randomness
			{
				for(int i=0; i<tgridL.getLeft().length; i++)
				{
					tgridL.getLeft()[i].setIcon(master.getLeft()[i].getIcon());
					tgridR.getRight()[i].setIcon(master.getRight()[i].getIcon());
				}
				
			}
			//--------------------------------------------------------------------------------------
			
			
			
			
			else if(r%2 == 0) //On every even press switch L->R and R->L for added randomness
			{
				
				for(int i=0; i<tgridL.getLeft().length; i++)
				{
					tgridL.getLeft()[i].setIcon(master.getRight()[i].getIcon());
					tgridR.getRight()[i].setIcon(master.getLeft()[i].getIcon());
				}
				

			}
			//-----------------------------------------------------
			
			
			for(int i=0; i<gb.getTiles().length; i++) //set board icons to null for reset
			{
				gb.getTiles()[i].setIcon(null);
				gb.getTiles()[i].setIdentifier(null);
			}
			//-----------------------------------------------------
			
			
			JOptionPane.showMessageDialog(null, "Game has been reset!");
			r++;
			return;
		}
		//--------------------------------------------------------------------------------------
		
		
		
		
		else if(e.getActionCommand() == "Solve")
		{
			
			
			
			for(int i = 0; i < tgridL.getLeft().length; i++)
			{
				tgridL.getLeft()[i].setIcon(null); //Remove Icons from TileGrids
				tgridR.getRight()[i].setIcon(null);
				tgridL.getLeft()[i].setBorder(BorderFactory.createLineBorder(vanilla,2,true));
				tgridR.getRight()[i].setBorder(BorderFactory.createLineBorder(vanilla,2,true));
		
			}
			//-----------------------------------------------------
			
			
			
			for(int i=0; i<gb.getTiles().length; i++) //get/set winning position
			{
				gb.getTiles()[i].setIcon(solve.getWinningTiles().getSolve()[i].getIcon());
				gb.getTiles()[i].setIdentifier(solve.getWinningTiles().getSolve()[i].getIdentifier());
			}
			//-----------------------------------------------------
			
			
			gameWon();  //Check
			return;
		}
		//--------------------------------------------------------------------------------------
		
		
		
		
		else if(e.getActionCommand() == "Check")  //In case you want to check mid way
		{
			gb.print();
			if(gb.gameWon())
			{
				JOptionPane.showMessageDialog(null, "You Win!");
			}
			else
			{
				JOptionPane.showMessageDialog(null, "Wrong!");
			}
			return;
			
		}
		//--------------------------------------------------------------------------------------
		
		
		
		
		else if(e.getActionCommand() == "New Image-UC")  //Under Construction
		{
	
			JOptionPane.showMessageDialog(null, "New Image Pressed");
			return;
		}
		//--------------------------------------------------------------------------------------
		
		
		
		
		else //You are working with Tiles so start swapping
		{
			if(tilesToSwap[0] == null)
			{
				Border border = new LineBorder(Color.blue, 3);  //Highlight Tile to be swapped
				tilesToSwap[0] = (Tile) e.getSource();
				tilesToSwap[0].setBorder(border);
			}
			
			
			else
			{
				tilesToSwap[1] = (Tile) e.getSource();
				swapTiles(tilesToSwap[0], tilesToSwap[1]);
				tilesToSwap[0] = null;
				tilesToSwap[1] = null;
				gameWon();
			}			
		}
		//--------------------------------------------------------------------------------------
		
		
		
	}
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	
	
	
	//check if game has been won
	public void gameWon()
	{
		if(gb.gameWon())
		{
			JOptionPane.showMessageDialog(null, "You Win!"+"\n"+"Your Time Was: "+ "\n"+ timer.getTime());
		}
	}
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	
	
	
	
	public void insertGameTiles()
	{
		tgridL = new TileGrid();
		tgridL.setPreferredSize(tilegridDim);
		tgridL.setOpaque(false);
		//------------------------------------------------------
		
		
		tgridR = new TileGrid();
		tgridR.setPreferredSize(tilegridDim);
		tgridR.setOpaque(false);
	  //------------------------------------------------------
		
		
		
		master = new TileGrid();
	 //------------------------------------------------------
		
		
	    
		gb = new GameBoard();
		gb.setPreferredSize(gameboardDim);
		gb.setLayout(new GridBagLayout());
		gb.setBorder(BorderFactory.createLineBorder(new Color(243,229,171), 2));
		gb.setOpaque(false);
		//------------------------------------------------------
		
		
	
		//Tgrid0_7 setUp
		
		for(int i = 0; i < 8; i++) //add tiles to grid
		{
			tgridL.getLeft()[i] = master.getLeft()[i];
			tgridL.getLeft()[i].addActionListener(this);
			tgridL.add(tgridL.getLeft()[i]);
		}
		//------------------------------------------------------
		
		
		//Tgrid8_16 set Up
		
		for(int i = 0; i < 8; i++)  //add tiles to grid
		{
			tgridR.getRight()[i] = master.getRight()[i];
			tgridR.getRight()[i].addActionListener(this);
			tgridR.add(tgridR.getRight()[i]);
		}
		
		//------------------------------------------------------
		
		
		//Game Board SetUp
		
		GameBoardSetUp();
		
		//------------------------------------------------------
		
		
		//Set Border For Tiles
		 
		for(int i = 0; i< tgridL.getLeft().length; i++)
		{
			tgridL.getLeft()[i].setBorder(BorderFactory.createLineBorder(vanilla,2,true));
			tgridR.getRight()[i].setBorder(BorderFactory.createLineBorder(vanilla,2,true));
		}
		
	}
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	
	
	
	public void windowSetUp(JComponent component)
	{
		GridBagConstraints c = new GridBagConstraints();
		//------------------------------------------------------
		
		
		c.anchor = GridBagConstraints.CENTER;
		//c.fill = GridBagConstraints.BOTH;
		c.weightx = 0.0;
		c.weighty = 0.0;
		c.insets = new Insets(0,295,10,0);
		c.gridx = 2;
		c.gridy = 2;
		c.gridwidth = 1;
		c.gridheight = 1;
		component.add(gb, c);
		//------------------------------------------------------
		
		
		c.anchor = GridBagConstraints.LAST_LINE_START;
		c.fill = GridBagConstraints.HORIZONTAL;
		c.weightx = 0.0001;
		c.weighty = 0.0001;
		c.ipady = 0;
		c.ipadx = 0;
		c.insets = new Insets(0,0,0,0);
		c.gridx = 1;
		c.gridy = 2;
		c.gridwidth = 3;
		component.add(bgrid,c);
		//------------------------------------------------------
		
		
		c.anchor = GridBagConstraints.LINE_START;
		c.fill = GridBagConstraints.VERTICAL;
		c.gridx = 0;
		c.insets = new Insets(135,10,0,0);
		c.weightx = 0.0001;
		c.weighty = 0.0001;
		component.add(tgridL,c);
		//------------------------------------------------------
		
		
		c.anchor = GridBagConstraints.LINE_END;
		c.fill = GridBagConstraints.VERTICAL;
		c.gridx = 3;
		c.insets = new Insets(135,0,0,10);
		c.weightx = 0.0001;
		c.weighty = 0.0001;
		component.add(tgridR, c);
		//------------------------------------------------------
		
		
	}
	
	private void GameBoardSetUp()
	{
		GridBagConstraints c = new GridBagConstraints();
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		c.insets = new Insets(0,0,0,0);
		c.ipady = 0;
		c.ipadx = 0;
		c.weightx = 0.0001;
		c.weighty = 0.0001;
		c.gridx = 0;
		c.gridy = 0;
		//------------------------------------------------------
		
		/*GridBagConstraints basic = new GridBagConstraints();
		int y = 1;
		for(int i = 0; i < gb.getTiles().length; i++)  //add tiles to board
		{
			if(i % 4 == 0)
	    	  {
	    		  basic.gridy = y;
	    		  gb.getTiles()[i].addActionListener(this);
	    		  gb.add(gb.getTiles()[i], basic);
	    		  y++;
	    		  gb.getTiles()[i].setBorder(BorderFactory.createEmptyBorder());
	    	  }
	    	  else
	    	  {
	    		  gb.add(gb.getTiles()[i], basic);
	    		  gb.getTiles()[i].addActionListener(this);
	    		  gb.getTiles()[i].setBorder(BorderFactory.createEmptyBorder());
	    	  }
		}*/
		for(int i = 0; i < gb.getTiles().length; i++)  //add tiles to board
		{
			gb.getTiles()[i].addActionListener(this);
			gb.getTiles()[i].setBorder(BorderFactory.createEmptyBorder());
		}
		//------------------------------------------------------
		
		
		{
			gb.add(gb.getTiles()[0],c);
			c.insets = new Insets(0,78,0,0);
			gb.add(gb.getTiles()[1],c);
			c.insets = new Insets(0,155,0,0);
			gb.add(gb.getTiles()[2],c);
			c.insets = new Insets(0,233,0,0);
			gb.add(gb.getTiles()[3],c);
			c.insets = new Insets(78,0,0,0);
			gb.add(gb.getTiles()[4],c);
			c.insets = new Insets(78,78,0,0);
			gb.add(gb.getTiles()[5],c);
			c.insets = new Insets(78,155,0,0);
			gb.add(gb.getTiles()[6],c);
			c.insets = new Insets(78,233,0,0);
			gb.add(gb.getTiles()[7],c);
			c.insets = new Insets(155,0,0,0);
			gb.add(gb.getTiles()[8],c);
			c.insets = new Insets(155,78,0,0);
			gb.add(gb.getTiles()[9],c);
			c.insets = new Insets(155,155,0,0);
			gb.add(gb.getTiles()[10],c);
			c.insets = new Insets(155,233,0,0);
			gb.add(gb.getTiles()[11],c);
			c.insets = new Insets(233,0,0,0);
			gb.add(gb.getTiles()[12],c);
			c.insets = new Insets(233,78,0,0);
			gb.add(gb.getTiles()[13],c);
			c.insets = new Insets(233,155,0,0);
			gb.add(gb.getTiles()[14],c);
			c.insets = new Insets(233,233,0,0);
			gb.add(gb.getTiles()[15],c);
		}
		//------------------------------------------------------
		
	}
	
}
